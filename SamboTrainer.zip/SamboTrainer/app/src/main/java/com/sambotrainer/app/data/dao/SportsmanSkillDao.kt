package com.sambotrainer.app.data.dao

import androidx.room.*
import com.sambotrainer.app.data.entity.SkillStatus
import com.sambotrainer.app.data.entity.SportsmanSkill
import kotlinx.coroutines.flow.Flow

@Dao
interface SportsmanSkillDao {

    @Query("SELECT * FROM sportsman_skills WHERE sportsmanId = :sportsmanId ORDER BY createdAt DESC")
    fun observeForSportsman(sportsmanId: Long): Flow<List<SportsmanSkill>>

    @Query("SELECT * FROM sportsman_skills WHERE sportsmanId = :sportsmanId AND status = :status ORDER BY createdAt DESC")
    fun observeForSportsmanByStatus(sportsmanId: Long, status: SkillStatus): Flow<List<SportsmanSkill>>

    @Query("SELECT * FROM sportsman_skills WHERE id = :id")
    suspend fun getById(id: Long): SportsmanSkill?

    @Query("SELECT COUNT(*) FROM sportsman_skills WHERE sportsmanId = :sportsmanId AND skillId = :skillId")
    suspend fun countExisting(sportsmanId: Long, skillId: Long): Int

    @Query("SELECT COUNT(*) FROM sportsman_skills WHERE skillId = :skillId")
    suspend fun countUsingSkill(skillId: Long): Int

    @Insert
    suspend fun insert(sportsmanSkill: SportsmanSkill): Long

    @Update
    suspend fun update(sportsmanSkill: SportsmanSkill)

    @Delete
    suspend fun delete(sportsmanSkill: SportsmanSkill)
}
