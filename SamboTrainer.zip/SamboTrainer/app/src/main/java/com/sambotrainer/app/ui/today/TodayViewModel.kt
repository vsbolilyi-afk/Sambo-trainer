package com.sambotrainer.app.ui.today

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.domain.TrainingSessionGenerator
import com.sambotrainer.app.util.DateUtils
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Одна строка списка тренировок на главном экране (п.6). */
data class TodaySessionUi(
    val sessionId: Long,
    val groupId: Long,
    val groupName: String,
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int,
    val sportsmanCount: Int
)

class TodayViewModel(private val database: AppDatabase) : ViewModel() {

    val today: LocalDate = LocalDate.now()

    init {
        // Автоматическое создание тренировок по расписанию на сегодня (п.10) —
        // происходит незаметно для тренера при каждом открытии главного экрана.
        viewModelScope.launch {
            TrainingSessionGenerator.ensureSessionsForDate(database, today)
        }
    }

    val sessions: StateFlow<List<TodaySessionUi>> = combine(
        database.trainingSessionDao().observeForDay(DateUtils.toEpochDayStart(today)),
        database.groupDao().observeAll()
    ) { sessions, groups -> sessions to groups }
        .map { (sessions, groups) ->
            val groupsById = groups.associateBy { it.id }
            sessions
                .sortedBy { it.startMinuteOfDay }
                .map { session ->
                    val group = groupsById[session.groupId]
                    val count = database.sportsmanDao().getActiveByGroup(session.groupId).size
                    TodaySessionUi(
                        sessionId = session.id,
                        groupId = session.groupId,
                        groupName = group?.name ?: "Группа",
                        startMinuteOfDay = session.startMinuteOfDay,
                        endMinuteOfDay = session.endMinuteOfDay,
                        sportsmanCount = count
                    )
                }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
}
