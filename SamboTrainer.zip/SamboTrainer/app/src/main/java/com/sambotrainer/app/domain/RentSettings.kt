package com.sambotrainer.app.domain

/**
 * Стоимость аренды за тренировочный день по умолчанию (п.36).
 * Как и цены абонементов, переедет в редактируемые настройки в Фазе 7.
 */
object RentSettings {
    const val RENT_PER_TRAINING_DAY = 1500
}
