package com.sambotrainer.app.util

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Утилиты для работы с датами. Используем java.time (доступно нативно с API 26,
 * что совпадает с minSdk проекта — без дополнительного desugaring).
 *
 * Даты в БД хранятся как epoch millis начала суток в системной таймзоне устройства —
 * этого достаточно для локального однопользовательского приложения (п.3-4).
 */
object DateUtils {

    private val zoneId: ZoneId = ZoneId.systemDefault()

    fun toEpochDayStart(date: LocalDate): Long =
        date.atStartOfDay(zoneId).toInstant().toEpochMilli()

    fun epochToLocalDate(epochMillis: Long): LocalDate =
        Instant.ofEpochMilli(epochMillis).atZone(zoneId).toLocalDate()

    /** Ключ месяца в формате "YYYY-MM", используется для Payment.month (п.13). */
    fun monthKey(date: LocalDate): String =
        "%04d-%02d".format(date.year, date.monthValue)

    private val monthsGenitive = listOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )

    private val monthsNominative = listOf(
        "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
        "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
    )

    private val weekdaysShort = listOf("ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС")

    /** "4 сентября" — формат заголовка главного экрана (п.6). */
    fun formatDayMonth(date: LocalDate): String =
        "${date.dayOfMonth} ${monthsGenitive[date.monthValue - 1]}"

    fun monthNominative(monthValue: Int): String = monthsNominative[monthValue - 1]

    fun weekdayShort(date: LocalDate): String = weekdaysShort[date.dayOfWeek.value - 1]

    /** Название дня недели по числу 1..7 (для редактора расписания, п.9/47). */
    fun weekdayLabel(weekday: Int): String = weekdaysShort[weekday - 1]

    /** "17:00" из минут от начала суток. */
    fun formatMinuteOfDay(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return "%02d:%02d".format(h, m)
    }
}
