package com.sambotrainer.app.ui.finance

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Expense
import com.sambotrainer.app.data.entity.ExpenseType
import com.sambotrainer.app.util.DateUtils

@Composable
fun FinanceScreen(database: AppDatabase, settingsRepository: com.sambotrainer.app.data.settings.SettingsRepository) {
    val viewModel: FinanceViewModel = viewModel(
        factory = viewModelFactory { initializer { FinanceViewModel(database, settingsRepository) } }
    )
    val month by viewModel.currentMonth.collectAsState()
    val state by viewModel.uiState.collectAsState()
    var showAddExpense by remember { mutableStateOf(false) }
    var showPaidList by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddExpense = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Добавить расход")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 16.dp)) {
            Text("Финансы", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.goToPreviousMonth() }) {
                    Icon(Icons.Filled.ChevronLeft, contentDescription = "Предыдущий месяц")
                }
                Text(
                    "${DateUtils.monthNominative(month.monthValue)} ${month.year}",
                    style = MaterialTheme.typography.titleMedium
                )
                IconButton(onClick = { viewModel.goToNextMonth() }) {
                    Icon(Icons.Filled.ChevronRight, contentDescription = "Следующий месяц")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            SummaryCard(
                income = state.income,
                paidCount = state.paidCount,
                unpaidCount = state.unpaidCount,
                totalExpenses = state.totalExpenses,
                result = state.result,
                onPaidClick = { showPaidList = true }
            )

            Spacer(modifier = Modifier.height(20.dp))
            Text("Расходы", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))

            if (state.expenses.isEmpty()) {
                Text("Расходов пока нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn {
                    items(state.expenses, key = { it.id }) { expense ->
                        ExpenseRow(
                            expense = expense,
                            onDelete = { viewModel.deleteExpense(expense) }
                        )
                    }
                }
            }
        }
    }

    if (showAddExpense) {
        AddExpenseDialog(
            onDismiss = { showAddExpense = false },
            onSave = { name, amount, comment ->
                viewModel.addManualExpense(name, amount, comment)
                showAddExpense = false
            }
        )
    }

    if (showPaidList) {
        PaidListDialog(
            monthLabel = "${DateUtils.monthNominative(month.monthValue)} ${month.year}",
            entries = state.paidList,
            total = state.income,
            onDismiss = { showPaidList = false }
        )
    }
}

@Composable
private fun SummaryCard(
    income: Int,
    paidCount: Int,
    unpaidCount: Int,
    totalExpenses: Int,
    result: Int,
    onPaidClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text("Доход", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$income ₽", style = MaterialTheme.typography.headlineSmall)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onPaidClick),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Оплатили: $paidCount   Не оплатили: $unpaidCount",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "Список ›",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text("Расходы", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("$totalExpenses ₽", style = MaterialTheme.typography.headlineSmall)

            Spacer(modifier = Modifier.height(14.dp))
            Text("Результат", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "$result ₽",
                style = MaterialTheme.typography.headlineMedium,
                color = if (result >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
private fun ExpenseRow(expense: Expense, onDelete: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(expense.name, style = MaterialTheme.typography.bodyLarge)
            Text(
                DateUtils.formatDayMonth(DateUtils.epochToLocalDate(expense.date)) +
                    (expense.comment?.let { " · $it" } ?: ""),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${expense.amount} ₽", style = MaterialTheme.typography.bodyLarge)
            if (expense.type == ExpenseType.MANUAL) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Удалить")
                }
            }
        }
    }
}

@Composable
private fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (String, Int, String?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый расход") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название") },
                    placeholder = { Text("Например: Инвентарь") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                    label = { Text("Сумма, ₽") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Комментарий (необязательно)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(name, amountText.toIntOrNull() ?: 0, comment) },
                enabled = name.isNotBlank() && (amountText.toIntOrNull() ?: 0) > 0
            ) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

@Composable
private fun PaidListDialog(
    monthLabel: String,
    entries: List<PaidEntry>,
    total: Int,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Оплатили — $monthLabel") },
        text = {
            if (entries.isEmpty()) {
                Text("Пока никто не оплатил", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(modifier = Modifier.height(320.dp)) {
                    items(entries) { entry ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(entry.fullName, style = MaterialTheme.typography.bodyLarge)
                            Text("${entry.amount} ₽", style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                    item {
                        androidx.compose.material3.HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Итого", style = MaterialTheme.typography.titleMedium)
                            Text("$total ₽", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Закрыть") }
        }
    )
}
