package com.sambotrainer.app.data.dao

import androidx.room.*
import com.sambotrainer.app.data.entity.Attendance
import com.sambotrainer.app.data.entity.AttendanceStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {

    @Query("SELECT * FROM attendance WHERE trainingSessionId = :sessionId")
    fun observeForSession(sessionId: Long): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE trainingSessionId = :sessionId")
    suspend fun getForSession(sessionId: Long): List<Attendance>

    @Query("SELECT * FROM attendance WHERE sportsmanId = :sportsmanId ORDER BY createdAt DESC")
    fun observeForSportsman(sportsmanId: Long): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE sportsmanId = :sportsmanId")
    suspend fun getForSportsman(sportsmanId: Long): List<Attendance>

    @Query(
        """
        SELECT * FROM attendance
        WHERE sportsmanId = :sportsmanId AND sportsmanId IN (
            SELECT sportsmanId FROM attendance a
            JOIN training_sessions t ON a.trainingSessionId = t.id
            WHERE t.date >= :monthStart AND t.date <= :monthEnd
        )
        """
    )
    suspend fun getForSportsmanRaw(sportsmanId: Long, monthStart: Long, monthEnd: Long): List<Attendance>

    @Query(
        """
        SELECT a.* FROM attendance a
        JOIN training_sessions t ON a.trainingSessionId = t.id
        WHERE a.sportsmanId = :sportsmanId
          AND a.status = :status
          AND t.date >= :from AND t.date <= :to
        ORDER BY t.date ASC
        """
    )
    suspend fun getForSportsmanInRangeWithStatus(
        sportsmanId: Long,
        status: AttendanceStatus,
        from: Long,
        to: Long
    ): List<Attendance>

    @Query("SELECT * FROM attendance WHERE sportsmanId = :sportsmanId AND trainingSessionId = :sessionId LIMIT 1")
    suspend fun getOne(sportsmanId: Long, sessionId: Long): Attendance?

    @Upsert
    suspend fun upsert(attendance: Attendance)

    @Upsert
    suspend fun upsertAll(attendance: List<Attendance>)
}
