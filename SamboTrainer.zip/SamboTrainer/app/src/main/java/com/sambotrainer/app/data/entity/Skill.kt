package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Общий каталог навыков (п.26), редактируемый тренером в настройках.
 * Например: "Кувырок вперёд", "Самостраховка", "Бросок через бедро".
 */
@Entity(tableName = "skills")
data class Skill(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val active: Boolean = true
)
