package com.sambotrainer.app.ui.sportsmen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Note
import com.sambotrainer.app.util.DateUtils

@Composable
fun NotesSection(database: AppDatabase, sportsmanId: Long) {
    val viewModel: NotesViewModel = viewModel(
        factory = viewModelFactory { initializer { NotesViewModel(database, sportsmanId) } }
    )
    val notes by viewModel.notes.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf<Note?>(null) }

    Column {
        TextButton(onClick = { showAddDialog = true }) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.height(18.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text("Добавить заметку")
        }

        if (notes.isEmpty()) {
            Text(
                "Заметок пока нет",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            notes.forEach { note ->
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            DateUtils.formatDayMonth(DateUtils.epochToLocalDate(note.date)),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row {
                            IconButton(onClick = { editTarget = note }, modifier = Modifier.height(28.dp)) {
                                Icon(Icons.Filled.Edit, contentDescription = "Изменить")
                            }
                            IconButton(onClick = { viewModel.delete(note) }, modifier = Modifier.height(28.dp)) {
                                Icon(Icons.Filled.Delete, contentDescription = "Удалить")
                            }
                        }
                    }
                    Text(note.text, style = MaterialTheme.typography.bodyLarge)
                }
                HorizontalDivider()
            }
        }
    }

    if (showAddDialog) {
        NoteEditDialog(
            initialText = "",
            title = "Новая заметка",
            onDismiss = { showAddDialog = false },
            onSave = { text ->
                viewModel.add(text)
                showAddDialog = false
            }
        )
    }

    editTarget?.let { note ->
        NoteEditDialog(
            initialText = note.text,
            title = "Изменить заметку",
            onDismiss = { editTarget = null },
            onSave = { text ->
                viewModel.update(note, text)
                editTarget = null
            }
        )
    }
}

@Composable
private fun NoteEditDialog(
    initialText: String,
    title: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var text by remember { mutableStateOf(initialText) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(text) }, enabled = text.isNotBlank()) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}
