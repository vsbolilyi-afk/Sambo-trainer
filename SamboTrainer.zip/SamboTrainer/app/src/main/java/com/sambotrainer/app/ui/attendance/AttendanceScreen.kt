package com.sambotrainer.app.ui.attendance

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.AttendanceStatus
import com.sambotrainer.app.data.settings.SettingsRepository
import com.sambotrainer.app.ui.sportsmen.PaymentTypeDialog
import com.sambotrainer.app.util.DateUtils

@Composable
fun AttendanceScreen(
    database: AppDatabase,
    settingsRepository: SettingsRepository,
    sessionId: Long,
    onBack: () -> Unit
) {
    val viewModel: AttendanceViewModel = viewModel(
        factory = viewModelFactory { initializer { AttendanceViewModel(database, settingsRepository, sessionId) } }
    )
    val session by viewModel.session.collectAsState()
    val groupName by viewModel.groupName.collectAsState()
    val rows by viewModel.rows.collectAsState()
    val context = LocalContext.current

    var paymentTargetId by remember { mutableStateOf<Long?>(null) }
    var paymentTargetName by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(groupName) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 12.dp)) {
            session?.let {
                Text(
                    "${DateUtils.formatMinuteOfDay(it.startMinuteOfDay)}–${DateUtils.formatMinuteOfDay(it.endMinuteOfDay)}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            Button(
                onClick = { viewModel.markAllPresent(context) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Check, contentDescription = null)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Все пришли")
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (rows.isEmpty()) {
                Text(
                    "В этой группе пока нет спортсменов",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(rows, key = { it.sportsmanId }) { row ->
                        AttendanceRow(
                            fullName = row.fullName,
                            status = row.status,
                            paidThisMonth = row.paidThisMonth,
                            paidAmount = row.paidAmount,
                            onStatusClick = { viewModel.cycleStatus(context, row.sportsmanId, row.fullName, row.status) },
                            onPaymentClick = {
                                paymentTargetId = row.sportsmanId
                                paymentTargetName = row.fullName
                            }
                        )
                    }
                }
            }
        }
    }

    paymentTargetId?.let { sportsmanId ->
        PaymentTypeDialog(
            settingsRepository = settingsRepository,
            sportsmanName = paymentTargetName,
            onDismiss = { paymentTargetId = null },
            onConfirm = { type, amount, comment ->
                viewModel.markPayment(sportsmanId, type, amount, comment)
                paymentTargetId = null
            }
        )
    }
}

@Composable
private fun AttendanceRow(
    fullName: String,
    status: AttendanceStatus,
    paidThisMonth: Boolean,
    paidAmount: Int,
    onStatusClick: () -> Unit,
    onPaymentClick: () -> Unit
) {
    val (emoji, bg) = when (status) {
        AttendanceStatus.PRESENT -> "🟢" to MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
        AttendanceStatus.ABSENT -> "🔴" to MaterialTheme.colorScheme.error.copy(alpha = 0.08f)
        AttendanceStatus.NOT_MARKED -> "⚪" to MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bg)
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onStatusClick),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(fullName, style = MaterialTheme.typography.bodyLarge)
                Text(emoji, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    if (paidThisMonth) "🟢 Оплачено · $paidAmount ₽" else "🔴 Не оплачено",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (paidThisMonth) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error
                )
                TextButton(onClick = onPaymentClick) {
                    Text(if (paidThisMonth) "Добавить оплату" else "Отметить оплату")
                }
            }
        }
    }
}
