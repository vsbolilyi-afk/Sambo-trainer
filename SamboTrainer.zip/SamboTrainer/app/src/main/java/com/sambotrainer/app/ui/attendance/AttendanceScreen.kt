package com.sambotrainer.app.ui.attendance

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.AttendanceStatus
import com.sambotrainer.app.util.DateUtils

@Composable
fun AttendanceScreen(
    database: AppDatabase,
    sessionId: Long,
    onBack: () -> Unit
) {
    val viewModel: AttendanceViewModel = viewModel(
        factory = viewModelFactory { initializer { AttendanceViewModel(database, sessionId) } }
    )
    val session by viewModel.session.collectAsState()
    val groupName by viewModel.groupName.collectAsState()
    val rows by viewModel.rows.collectAsState()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(groupName) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 12.dp)) {
            session?.let {
                Text(
                    "${DateUtils.formatMinuteOfDay(it.startMinuteOfDay)}–${DateUtils.formatMinuteOfDay(it.endMinuteOfDay)}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            Button(
                onClick = { viewModel.markAllPresent(context) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Check, contentDescription = null)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Все пришли")
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (rows.isEmpty()) {
                Text(
                    "В этой группе пока нет спортсменов",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(rows, key = { it.sportsmanId }) { row ->
                        AttendanceRow(
                            fullName = row.fullName,
                            status = row.status,
                            onClick = { viewModel.cycleStatus(context, row.sportsmanId, row.fullName, row.status) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AttendanceRow(fullName: String, status: AttendanceStatus, onClick: () -> Unit) {
    val (emoji, bg) = when (status) {
        AttendanceStatus.PRESENT -> "🟢" to MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
        AttendanceStatus.ABSENT -> "🔴" to MaterialTheme.colorScheme.error.copy(alpha = 0.08f)
        AttendanceStatus.NOT_MARKED -> "⚪" to MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bg)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(fullName, style = MaterialTheme.typography.bodyLarge)
            Text(emoji, style = MaterialTheme.typography.titleLarge)
        }
    }
}
