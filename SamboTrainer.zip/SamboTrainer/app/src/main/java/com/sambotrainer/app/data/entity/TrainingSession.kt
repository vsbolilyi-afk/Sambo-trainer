package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Конкретная тренировка на конкретную дату (п.10).
 * Создаётся автоматически по Schedule, но хранится отдельно, чтобы
 * история (п.34 Архив) не зависела от последующих изменений расписания.
 * date хранится как epoch millis начала дня (UTC-независимый local date).
 */
@Entity(
    tableName = "training_sessions",
    foreignKeys = [
        ForeignKey(
            entity = Group::class,
            parentColumns = ["id"],
            childColumns = ["groupId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("groupId"), Index("date"), Index(value = ["groupId", "date"], unique = true)]
)
data class TrainingSession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long,
    val date: Long,          // epoch day start millis
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int,
    val sourceScheduleId: Long? = null // ссылка на строку расписания, породившую сессию
)
