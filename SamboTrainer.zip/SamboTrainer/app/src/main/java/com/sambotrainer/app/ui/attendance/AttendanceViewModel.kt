package com.sambotrainer.app.ui.attendance

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Attendance
import com.sambotrainer.app.data.entity.AttendanceStatus
import com.sambotrainer.app.data.entity.TrainingSession
import com.sambotrainer.app.domain.AttendanceStats
import com.sambotrainer.app.domain.UNPAID_ATTENTION_THRESHOLD
import com.sambotrainer.app.util.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AttendanceRowUi(
    val sportsmanId: Long,
    val fullName: String,
    val status: AttendanceStatus
)

class AttendanceViewModel(
    private val database: AppDatabase,
    private val sessionId: Long
) : ViewModel() {

    val session: MutableStateFlow<TrainingSession?> = MutableStateFlow(null)
    val groupName: MutableStateFlow<String> = MutableStateFlow("")

    init {
        viewModelScope.launch {
            val s = database.trainingSessionDao().getById(sessionId)
            session.value = s
            if (s != null) {
                groupName.value = database.groupDao().getById(s.groupId)?.name ?: ""
            }
        }
    }

    val rows: StateFlow<List<AttendanceRowUi>> = combine(
        session,
        database.attendanceDao().observeForSession(sessionId)
    ) { s, attendanceRecords ->
        if (s == null) return@combine emptyList()
        val sportsmen = database.sportsmanDao().getActiveByGroup(s.groupId)
        val statusBySportsman = attendanceRecords.associateBy { it.sportsmanId }
        sportsmen.map { sp ->
            AttendanceRowUi(
                sportsmanId = sp.id,
                fullName = sp.fullName,
                status = statusBySportsman[sp.id]?.status ?: AttendanceStatus.NOT_MARKED
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    /** Одно нажатие циклически меняет статус (п.11): не отмечено -> посетил -> не посетил -> не отмечено. */
    fun cycleStatus(context: Context, sportsmanId: Long, fullName: String, current: AttendanceStatus) {
        val next = when (current) {
            AttendanceStatus.NOT_MARKED -> AttendanceStatus.PRESENT
            AttendanceStatus.PRESENT -> AttendanceStatus.ABSENT
            AttendanceStatus.ABSENT -> AttendanceStatus.NOT_MARKED
        }
        viewModelScope.launch {
            val existing = database.attendanceDao().getOne(sportsmanId, sessionId)
            database.attendanceDao().upsert(
                Attendance(
                    id = existing?.id ?: 0,
                    sportsmanId = sportsmanId,
                    trainingSessionId = sessionId,
                    status = next,
                    createdAt = existing?.createdAt ?: System.currentTimeMillis()
                )
            )
            if (next == AttendanceStatus.PRESENT) {
                checkUnpaidThresholdAndNotify(context, sportsmanId, fullName)
            }
        }
    }

    /** "Все пришли" (п.12): всем сразу ставится "Посетил", дальше тренер точечно правит отсутствующих. */
    fun markAllPresent(context: Context) {
        viewModelScope.launch {
            val sportsmen = rows.value
            val existingRecords = database.attendanceDao().getForSession(sessionId).associateBy { it.sportsmanId }
            database.attendanceDao().upsertAll(
                sportsmen.map { row ->
                    val existing = existingRecords[row.sportsmanId]
                    Attendance(
                        id = existing?.id ?: 0,
                        sportsmanId = row.sportsmanId,
                        trainingSessionId = sessionId,
                        status = AttendanceStatus.PRESENT,
                        createdAt = existing?.createdAt ?: System.currentTimeMillis()
                    )
                }
            )
            sportsmen.forEach { row -> checkUnpaidThresholdAndNotify(context, row.sportsmanId, row.fullName) }
        }
    }

    /** Уведомление срабатывает ровно в момент пересечения порога (п.16-17), а не при каждой отметке. */
    private suspend fun checkUnpaidThresholdAndNotify(context: Context, sportsmanId: Long, fullName: String) {
        val stats = AttendanceStats.compute(database, sportsmanId)
        if (!stats.paidThisMonth && stats.unpaidPresentCountThisMonth == UNPAID_ATTENTION_THRESHOLD) {
            NotificationHelper.notifyUnpaidAttention(context.applicationContext, sportsmanId, fullName)
        }
    }
}
