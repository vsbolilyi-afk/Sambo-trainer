package com.sambotrainer.app.ui.sportsmen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Sportsman
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AddSportsmanViewModel(private val database: AppDatabase) : ViewModel() {

    val groups: StateFlow<List<com.sambotrainer.app.data.entity.Group>> =
        database.groupDao().observeActive().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    /** Возвращает true, если спортсмен с таким же ФИО уже есть — предупреждаем, но не блокируем (п.53). */
    suspend fun isDuplicateName(fullName: String): Boolean =
        database.sportsmanDao().countByFullName(fullName.trim()) > 0

    fun save(
        fullName: String,
        birthDateMillis: Long,
        groupId: Long,
        parentName: String,
        parentPhone: String,
        sportsmanPhone: String,
        maxContact: String,
        telegramContact: String,
        socialContact: String,
        importantInformation: String,
        onDone: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val id = database.sportsmanDao().insert(
                Sportsman(
                    fullName = fullName.trim(),
                    birthDate = birthDateMillis,
                    groupId = groupId,
                    parentName = parentName.trim().ifBlank { null },
                    parentPhone = parentPhone.trim().ifBlank { null },
                    sportsmanPhone = sportsmanPhone.trim().ifBlank { null },
                    maxContact = maxContact.trim().ifBlank { null },
                    telegramContact = telegramContact.trim().ifBlank { null },
                    socialContact = socialContact.trim().ifBlank { null },
                    importantInformation = importantInformation.trim().ifBlank { null }
                )
            )
            onDone(id)
        }
    }
}
