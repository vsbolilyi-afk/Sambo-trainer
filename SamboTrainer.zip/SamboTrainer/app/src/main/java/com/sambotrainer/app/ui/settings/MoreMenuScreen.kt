package com.sambotrainer.app.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.sambotrainer.app.ui.navigation.DetailRoutes

private data class MenuItem(val title: String, val subtitle: String, val icon: ImageVector, val route: String)

@Composable
fun MoreMenuScreen(onNavigate: (String) -> Unit) {
    val items = listOf(
        MenuItem("Расписание", "Дни и время тренировок групп", Icons.Filled.CalendarMonth, DetailRoutes.SETTINGS_SCHEDULE),
        MenuItem("Группы", "Младшая, Старшая и другие группы", Icons.Filled.Groups, DetailRoutes.SETTINGS_GROUPS),
        MenuItem("Навыки", "Общий каталог навыков", Icons.Filled.School, DetailRoutes.SETTINGS_SKILLS),
        MenuItem("Абонементы и аренда", "Цены и стоимость зала", Icons.Filled.Payments, DetailRoutes.SETTINGS_PRICES),
        MenuItem("Архив спортсменов", "Восстановление и окончательное удаление", Icons.Filled.Inventory2, DetailRoutes.SETTINGS_ARCHIVE),
        MenuItem("Уведомления", "Оповещения о неоплаченных занятиях", Icons.Filled.Notifications, DetailRoutes.SETTINGS_NOTIFICATIONS),
        MenuItem("Резервное копирование", "Бэкап, восстановление, экспорт", Icons.Filled.SaveAlt, DetailRoutes.SETTINGS_BACKUP),
        MenuItem("О приложении", "SAMBO TRAINER", Icons.Filled.Info, DetailRoutes.SETTINGS_ABOUT)
    )

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text("Ещё", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))

        items.forEach { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigate(item.route) }
                    .padding(vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(item.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(0.dp))
                Column(modifier = Modifier.weight(1f).padding(start = 16.dp)) {
                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                    Text(item.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
