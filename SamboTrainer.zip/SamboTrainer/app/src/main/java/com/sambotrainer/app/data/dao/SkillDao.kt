package com.sambotrainer.app.data.dao

import androidx.room.*
import com.sambotrainer.app.data.entity.Skill
import kotlinx.coroutines.flow.Flow

@Dao
interface SkillDao {

    @Query("SELECT * FROM skills WHERE active = 1 ORDER BY name ASC")
    fun observeActive(): Flow<List<Skill>>

    @Query("SELECT * FROM skills ORDER BY name ASC")
    fun observeAll(): Flow<List<Skill>>

    @Query("SELECT * FROM skills WHERE id = :id")
    suspend fun getById(id: Long): Skill?

    @Insert
    suspend fun insert(skill: Skill): Long

    @Update
    suspend fun update(skill: Skill)

    @Delete
    suspend fun delete(skill: Skill)
}
