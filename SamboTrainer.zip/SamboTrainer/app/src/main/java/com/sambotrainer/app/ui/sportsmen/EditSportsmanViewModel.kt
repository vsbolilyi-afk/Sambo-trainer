package com.sambotrainer.app.ui.sportsmen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Group
import com.sambotrainer.app.data.entity.Sportsman
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EditSportsmanViewModel(
    private val database: AppDatabase,
    private val sportsmanId: Long
) : ViewModel() {

    val sportsman: MutableStateFlow<Sportsman?> = MutableStateFlow(null)

    val groups: StateFlow<List<Group>> = database.groupDao().observeActive()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            sportsman.value = database.sportsmanDao().getById(sportsmanId)
        }
    }

    /** Проверка на дубликат ФИО, исключая самого себя (иначе всегда бы срабатывало). */
    suspend fun isDuplicateName(fullName: String): Boolean {
        val count = database.sportsmanDao().countByFullName(fullName.trim())
        val currentHasThisName = sportsman.value?.fullName?.trim().equals(fullName.trim(), ignoreCase = false)
        return if (currentHasThisName) count > 1 else count > 0
    }

    fun save(
        fullName: String,
        birthDateMillis: Long,
        groupId: Long,
        parentName: String,
        parentPhone: String,
        sportsmanPhone: String,
        maxContact: String,
        telegramContact: String,
        socialContact: String,
        startDateMillis: Long?,
        importantInformation: String,
        parentNotes: String,
        onDone: () -> Unit
    ) {
        val current = sportsman.value ?: return
        viewModelScope.launch {
            database.sportsmanDao().update(
                current.copy(
                    fullName = fullName.trim(),
                    birthDate = birthDateMillis,
                    groupId = groupId,
                    parentName = parentName.trim().ifBlank { null },
                    parentPhone = parentPhone.trim().ifBlank { null },
                    sportsmanPhone = sportsmanPhone.trim().ifBlank { null },
                    maxContact = maxContact.trim().ifBlank { null },
                    telegramContact = telegramContact.trim().ifBlank { null },
                    socialContact = socialContact.trim().ifBlank { null },
                    startDate = startDateMillis,
                    importantInformation = importantInformation.trim().ifBlank { null },
                    parentNotes = parentNotes.trim().ifBlank { null }
                )
            )
            onDone()
        }
    }
}
