package com.sambotrainer.app.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Skill
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private class SkillsCatalogViewModel(private val database: AppDatabase) : ViewModel() {
    val skills = database.skillDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Одноразовое сообщение для пользователя (например, "навык отключён вместо удаления"). */
    val message = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)

    fun clearMessage() { message.value = null }

    fun add(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { database.skillDao().insert(Skill(name = name.trim())) }
    }

    fun rename(skill: Skill, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch { database.skillDao().update(skill.copy(name = newName.trim())) }
    }

    fun toggleActive(skill: Skill) {
        viewModelScope.launch { database.skillDao().update(skill.copy(active = !skill.active)) }
    }

    /**
     * Удаление навыка, который уже назначен спортсменам, запрещено на уровне БД
     * (защита от битых связей — foreign key RESTRICT), иначе приложение упало бы
     * с необработанным исключением. Вместо падения — безопасно отключаем навык
     * и объясняем тренеру, что произошло.
     */
    fun delete(skill: Skill) {
        viewModelScope.launch {
            val usageCount = database.sportsmanSkillDao().countUsingSkill(skill.id)
            if (usageCount > 0) {
                database.skillDao().update(skill.copy(active = false))
                message.value = "Навык «${skill.name}» уже назначен спортсменам, поэтому вместо удаления он отключён."
            } else {
                database.skillDao().delete(skill)
            }
        }
    }
}

@Composable
fun SkillsCatalogScreen(database: AppDatabase, onBack: () -> Unit) {
    val viewModel: SkillsCatalogViewModel = viewModel(factory = viewModelFactory { initializer { SkillsCatalogViewModel(database) } })
    val skills by viewModel.skills.collectAsState()
    val message by viewModel.message.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf<Skill?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current

    androidx.compose.runtime.LaunchedEffect(message) {
        if (message != null) {
            android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
            viewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Навыки") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Filled.Add, contentDescription = "Добавить навык") }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 12.dp)) {
            items(skills, key = { it.id }) { skill ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            skill.name,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f).clickable { editTarget = skill }
                        )
                        Switch(checked = skill.active, onCheckedChange = { viewModel.toggleActive(skill) })
                        IconButton(onClick = { viewModel.delete(skill) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Удалить")
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        SkillNameDialog(title = "Новый навык", initial = "", onDismiss = { showAdd = false }, onSave = { viewModel.add(it); showAdd = false })
    }
    editTarget?.let { skill ->
        SkillNameDialog(title = "Переименовать навык", initial = skill.name, onDismiss = { editTarget = null }, onSave = { viewModel.rename(skill, it); editTarget = null })
    }
}

@Composable
private fun SkillNameDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onSave(text) }, enabled = text.isNotBlank()) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
