package com.sambotrainer.app.ui.finance

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Expense
import com.sambotrainer.app.data.entity.ExpenseType
import com.sambotrainer.app.data.entity.SportsmanStatus
import com.sambotrainer.app.data.settings.SettingsRepository
import com.sambotrainer.app.domain.TrainingSessionGenerator
import com.sambotrainer.app.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.YearMonth

data class PaidEntry(val fullName: String, val amount: Int)

data class FinanceUiState(
    val month: YearMonth = YearMonth.now(),
    val income: Int = 0,
    val paidCount: Int = 0,
    val unpaidCount: Int = 0,
    val expenses: List<Expense> = emptyList(),
    val totalExpenses: Int = 0,
    val result: Int = 0,
    val paidList: List<PaidEntry> = emptyList()
)

class FinanceViewModel(
    private val database: AppDatabase,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val currentMonth = MutableStateFlow(YearMonth.now())

    val uiState: StateFlow<FinanceUiState> = combine(
        currentMonth.flatMapLatest { month ->
            database.paymentDao().observeForMonth(DateUtils.monthKey(month.atDay(1)))
        },
        currentMonth.flatMapLatest { month ->
            database.expenseDao().observeForRange(
                DateUtils.toEpochDayStart(month.atDay(1)),
                DateUtils.toEpochDayStart(month.atEndOfMonth())
            )
        },
        currentMonth,
        database.sportsmanDao().observeByStatus(SportsmanStatus.ACTIVE)
    ) { payments, expenses, month, activeSportsmen ->
        ensureRentExpense(month)

        val income = payments.sumOf { it.amount }
        val totalExpenses = expenses.sumOf { it.amount }
        val paidIds = payments.map { it.sportsmanId }.toSet()
        val amountBySportsman = payments.groupBy { it.sportsmanId }.mapValues { (_, list) -> list.sumOf { it.amount } }

        val paidList = activeSportsmen
            .filter { it.id in paidIds }
            .map { PaidEntry(fullName = it.fullName, amount = amountBySportsman[it.id] ?: 0) }
            .sortedByDescending { it.amount }

        FinanceUiState(
            month = month,
            income = income,
            paidCount = activeSportsmen.count { it.id in paidIds },
            unpaidCount = activeSportsmen.count { it.id !in paidIds },
            expenses = expenses.sortedByDescending { it.date },
            totalExpenses = totalExpenses,
            result = income - totalExpenses,
            paidList = paidList
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = FinanceUiState()
    )

    /**
     * Пересчитывает автоматический расход аренды за месяц (п.36): количество
     * тренировочных дней × цена. Идемпотентно — если значение уже верное,
     * запись в БД не делается (иначе реактивный Flow расходов зациклился бы сам на себя).
     */
    private suspend fun ensureRentExpense(month: YearMonth) {
        val start = DateUtils.toEpochDayStart(month.atDay(1))
        val end = DateUtils.toEpochDayStart(month.atEndOfMonth())

        TrainingSessionGenerator.ensureSessionsForRange(database, month.atDay(1), month.atEndOfMonth())
        val trainingDays = database.trainingSessionDao().countInRange(start, end)
        val rentPerDay = settingsRepository.rentPerDay.first()
        val expectedAmount = trainingDays * rentPerDay

        val existingRent = database.expenseDao().getForRange(start, end).filter { it.type == ExpenseType.RENT }
        val alreadyCorrect = existingRent.size == 1 && existingRent.first().amount == expectedAmount
        val bothEmpty = existingRent.isEmpty() && trainingDays == 0
        if (alreadyCorrect || bothEmpty) return

        database.expenseDao().deleteRentForRange(start, end)
        if (trainingDays > 0) {
            database.expenseDao().insert(
                Expense(
                    name = "Аренда",
                    amount = expectedAmount,
                    date = start,
                    type = ExpenseType.RENT,
                    comment = "$trainingDays тренировочных дней"
                )
            )
        }
    }

    fun goToPreviousMonth() {
        currentMonth.value = currentMonth.value.minusMonths(1)
    }

    fun goToNextMonth() {
        currentMonth.value = currentMonth.value.plusMonths(1)
    }

    /** Ручной расход (п.37), например "Инвентарь — 3000₽". */
    fun addManualExpense(name: String, amount: Int, comment: String?) {
        if (name.isBlank() || amount <= 0) return
        viewModelScope.launch {
            database.expenseDao().insert(
                Expense(
                    name = name.trim(),
                    amount = amount,
                    date = System.currentTimeMillis(),
                    type = ExpenseType.MANUAL,
                    comment = comment?.trim()?.ifBlank { null }
                )
            )
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch { database.expenseDao().delete(expense) }
    }
}
