package com.sambotrainer.app.ui.calendar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.TrainingSession
import com.sambotrainer.app.domain.TrainingSessionGenerator
import com.sambotrainer.app.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

data class CalendarSessionUi(
    val sessionId: Long,
    val groupName: String,
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int
)

class CalendarViewModel(private val database: AppDatabase) : ViewModel() {

    val currentMonth = MutableStateFlow(YearMonth.now())
    val selectedDate = MutableStateFlow(LocalDate.now())

    /** При смене месяца гарантируем, что тренировки по расписанию созданы на весь видимый диапазон (п.10, 32-33). */
    private val ensuredSessions = currentMonth.map { month ->
        viewModelScope.launch {
            TrainingSessionGenerator.ensureSessionsForRange(database, month.atDay(1), month.atEndOfMonth())
        }
        month
    }

    val sessionsByDate: StateFlow<Map<LocalDate, List<CalendarSessionUi>>> = combine(
        ensuredSessions.flatMapLatest { month ->
            database.trainingSessionDao().observeForRange(
                DateUtils.toEpochDayStart(month.atDay(1)),
                DateUtils.toEpochDayStart(month.atEndOfMonth())
            )
        },
        database.groupDao().observeAll()
    ) { sessions, groups ->
        val groupsById = groups.associateBy { it.id }
        sessions.groupBy { DateUtils.epochToLocalDate(it.date) }
            .mapValues { (_, list) ->
                list.sortedBy { it.startMinuteOfDay }.map { s ->
                    CalendarSessionUi(
                        sessionId = s.id,
                        groupName = groupsById[s.groupId]?.name ?: "Группа",
                        startMinuteOfDay = s.startMinuteOfDay,
                        endMinuteOfDay = s.endMinuteOfDay
                    )
                }
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    fun goToPreviousMonth() {
        currentMonth.value = currentMonth.value.minusMonths(1)
    }

    fun goToNextMonth() {
        currentMonth.value = currentMonth.value.plusMonths(1)
    }

    fun goToCurrentMonth() {
        currentMonth.value = YearMonth.now()
        selectedDate.value = LocalDate.now()
    }

    fun selectDate(date: LocalDate) {
        selectedDate.value = date
    }
}
