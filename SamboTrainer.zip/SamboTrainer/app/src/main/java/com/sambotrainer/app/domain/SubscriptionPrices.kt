package com.sambotrainer.app.domain

import com.sambotrainer.app.data.entity.PaymentType

/**
 * Цены абонементов по умолчанию (п.14).
 * В Фазе 7 появится экран настроек, где тренер сможет их менять —
 * тогда значения переедут в DataStore, а не будут константами.
 */
object SubscriptionPrices {
    const val MONTH_PRICE = 4500
    const val HALF_MONTH_PRICE = 3500
    const val SINGLE_PRICE = 600

    fun priceFor(type: PaymentType): Int = when (type) {
        PaymentType.MONTH -> MONTH_PRICE
        PaymentType.HALF_MONTH -> HALF_MONTH_PRICE
        PaymentType.SINGLE -> SINGLE_PRICE
    }

    fun labelFor(type: PaymentType): String = when (type) {
        PaymentType.MONTH -> "Месяц"
        PaymentType.HALF_MONTH -> "Полмесяца"
        PaymentType.SINGLE -> "Разовое занятие"
    }
}
