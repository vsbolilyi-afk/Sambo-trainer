package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Расход (п.36-38): автоматический (аренда за тренировочный день)
 * или ручной (введённый тренером).
 */
@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val amount: Int,
    val date: Long,
    val type: ExpenseType,
    val comment: String? = null
)
