package com.sambotrainer.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.sambotrainer.app.ui.SamboTrainerRoot
import com.sambotrainer.app.ui.theme.SamboTrainerTheme

/**
 * Точка входа приложения.
 *
 * Фазы 1-7: фундамент, навигация, спортсмены, навыки/заметки, календарь/архив,
 * финансы, настройки/резервное копирование/экспорт. Демо-данные и финальная
 * визуальная полировка — Фаза 8.
 */
class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* результат не критичен для работы приложения (п.46) */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()

        val app = application as SamboTrainerApp

        setContent {
            SamboTrainerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SamboTrainerRoot(
                        database = app.database,
                        settingsRepository = app.settingsRepository
                    )
                }
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
