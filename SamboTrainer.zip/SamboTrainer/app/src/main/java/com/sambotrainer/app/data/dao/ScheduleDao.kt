package com.sambotrainer.app.data.dao

import androidx.room.*
import com.sambotrainer.app.data.entity.Schedule
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduleDao {

    @Query("SELECT * FROM schedule ORDER BY weekday ASC, startMinuteOfDay ASC")
    fun observeAll(): Flow<List<Schedule>>

    @Query("SELECT * FROM schedule WHERE active = 1 ORDER BY weekday ASC, startMinuteOfDay ASC")
    suspend fun getAllActive(): List<Schedule>

    @Query("SELECT * FROM schedule WHERE active = 1 AND weekday = :weekday")
    suspend fun getActiveForWeekday(weekday: Int): List<Schedule>

    @Query("SELECT * FROM schedule WHERE groupId = :groupId ORDER BY weekday ASC")
    fun observeForGroup(groupId: Long): Flow<List<Schedule>>

    @Insert
    suspend fun insert(schedule: Schedule): Long

    @Update
    suspend fun update(schedule: Schedule)

    @Delete
    suspend fun delete(schedule: Schedule)
}
