package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Заметка в карточке спортсмена (п.30). Отдельно от "Важной информации" (п.31),
 * которая хранится прямо в Sportsman.importantInformation как единое текстовое поле.
 */
@Entity(
    tableName = "notes",
    foreignKeys = [
        ForeignKey(
            entity = Sportsman::class,
            parentColumns = ["id"],
            childColumns = ["sportsmanId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sportsmanId")]
)
data class Note(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sportsmanId: Long,
    val date: Long = System.currentTimeMillis(),
    val text: String
)
