package com.sambotrainer.app.demo

import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.settings.SettingsRepository

/**
 * Разовый импорт данных из анкеты регистрации (Google-форма "Новая форма (Ответы)")
 * поверх уже загруженного реального состава. Добавляет поля, которых раньше не
 * было в карточке: адрес, место обучения, желаемый результат, дополнительные
 * секции — и обогащает заметки о родителях (работа, доп. телефоны).
 *
 * Сопоставление сделано вручную по ФИО — в анкете встречаются варианты написания
 * фамилий (например "Чесных"/"Честных", "Деев"/"Дивеев", "Шейхутдинов"/"Шайхутдинов",
 * "Михальчев"/"Михальчёв") — там, где анкета выглядит более достоверным источником
 * (заполнена самим родителем), фамилия исправлена на вариант из анкеты.
 *
 * Два случая НЕ импортированы автоматически — требуют ручной проверки тренером:
 * - "Минкевич Антон Евгеньевич" (05.09.2018) — в анкете есть, но такого спортсмена
 *   в приложении ещё нет вообще; группа неизвестна, добавлять нужно вручную.
 * - Анкета "Казаков Сергей Сергеевич" (дата рождения 04.07.1997) — явно взрослый
 *   человек, похоже родитель по ошибке вписал свои данные вместо ребёнка
 *   "Казаков Александр". Данные не перенесены, чтобы не приписать чужую
 *   информацию ребёнку по ошибке.
 */
object RegistrationImporter {

    private data class Update(
        val currentFullName: String,
        val newFullName: String? = null,
        val address: String? = null,
        val school: String? = null,
        val desiredResult: String? = null,
        val extraSections: String? = null,
        val healthNote: String? = null,
        val parentInfo: String? = null
    )

    /** Значения "здоров"/"нет ограничений" и т.п. не переносим в "Важную информацию" — там должны быть только реальные ограничения. */
    private val noRestrictionValues = setOf("нет", "отсутствуют", "здоров", "нет ограничений")

    private val updates = listOf(
        Update(
            currentFullName = "Болилый Иван",
            address = "г. Москва, ул. Горького, 17",
            school = "Москва",
            desiredResult = "КМС",
            extraSections = "Танцы бальные",
            parentInfo = "Папа и мама"
        ),
        Update(
            currentFullName = "Шошин Ярослав",
            address = "Московская обл., г. Ступино, ул. Куйбышева, д.34, кв.47",
            school = "Школа №8, 1А",
            desiredResult = "Уверенность в себе и своих силах",
            extraSections = "Плавание",
            parentInfo = "Шошина Екатерина Андреевна, +79166516630, СФР России по г. Москве и Московской области"
        ),
        Update(
            currentFullName = "Карапунарлы Михаил",
            address = "г. Ступино, ул. Тимирязева, д.62/28, кв.75",
            school = "Лицей №2, 3 класс",
            desiredResult = "Выносливость, характер, стимул посещения",
            parentInfo = "Рощина Светлана Сергеевна, Карапунарлы Григорий Фёдорович"
        ),
        Update(
            currentFullName = "Есюнин Алексей",
            address = "д. Вальцово",
            school = "Детский сад «Радуга»",
            desiredResult = "Уверенность в себе, функциональное развитие, умение постоять за себя, призовые места на соревнованиях",
            extraSections = "Подготовка к школе «Почемучки»",
            parentInfo = "Есюнин Алексей, Есюнина Александра"
        ),
        Update(
            currentFullName = "Деев Марк",
            newFullName = "Дивеев Марк",
            address = "п. Зендиково, ул. Мицкая, 8А",
            school = "Детский сад, подготовительная группа",
            desiredResult = "Укрепление физической подготовки, дисциплина",
            extraSections = "Репетитор, подготовка к школе",
            parentInfo = "Суркова Мария Анатольевна, +79151511755, психолог; Дивеев Марат Равильевич, военнослужащий"
        ),
        Update(
            currentFullName = "Чесных Серафим",
            newFullName = "Честных Серафим",
            address = "г. Ступино, Приокский пер., д.9, кв.241",
            school = "МБОУ СОШ №9, группа 2 «Старшая»",
            healthNote = "Отсутствуют",
            desiredResult = "Общее физическое развитие",
            extraSections = "Школа Дошколят МБОУ СОШ №9, вт/чт 16:50–18:10",
            parentInfo = "Честных Денис Геннадьевич, в/ч 98577, +79911052620, +79616289610; Честных Елена Олеговна, ООО «ВДС», +79537472253"
        ),
        Update(
            currentFullName = "Чулков Иван",
            address = "г. Ступино",
            school = "СОШ №5, 2 класс",
            healthNote = "Не рекомендуются осевые нагрузки на спину",
            desiredResult = "Физическое развитие. Участвовать и побеждать на соревнованиях",
            parentInfo = "Чулков Юрий Константинович"
        ),
        Update(
            currentFullName = "Дуйшокеев Амир",
            address = "Приокский пер., д.9, к.1, 6 подъезд, кв.401",
            school = "СОШ №9 Ступино, 3д",
            healthNote = "Миопия",
            desiredResult = "Максимум",
            extraSections = "Нет, любит конструкторы лего",
            parentInfo = "Дуйшокеев Аваз Алтынбекович, +79621828288; суши-бар «Япошкин Роллс»"
        ),
        Update(
            currentFullName = "Плакунов Богдан",
            address = "Московская обл., г. Ступино, ул. Горького, д.23, кв.35",
            school = "МБОУ «Лицей №2», 4 «А»",
            desiredResult = "Чемпион мира по самбо",
            extraSections = "Футбол, велосипед",
            parentInfo = "Плакунов Роман Андреевич, +79911660600, военный; Плакунова Элина Витальевна, +79162198411, в декрете"
        ),
        Update(
            currentFullName = "Ребров Николай",
            address = "г. Ступино, СНТ «Москворецкий садовод», 1-я Москворецкая ул., д.11",
            school = "Д/с №21 «Надежда», выпускная группа",
            desiredResult = "Стать чемпионом мира",
            extraSections = "Подготовка к школе, лего-конструирование",
            parentInfo = "Реброва Татьяна Сергеевна, +79168684906, самозанятая; Ребров Николай Юрьевич, +79164145502, самозанятый"
        ),
        Update(
            currentFullName = "Михальчев Егор",
            newFullName = "Михальчёв Егор",
            address = "г. Ступино, СНТ «Лесная поляна»",
            school = "Лицей №1 (пока детский сад)",
            desiredResult = "Овладение приёмами самбо, сила, выносливость, уверенность в себе, умение побеждать страх",
            parentInfo = "Михальчёва Анна Сергеевна, +79153257685, в декретном отпуске; Михальчёв Максим Михайлович, +79168400673"
        ),
        Update(
            currentFullName = "Поликарпов Максим",
            address = "г. Ступино, ул. Андропова, д.81, кв.104",
            school = "Лицей №1, 7А класс",
            healthNote = "Нет ограничений",
            desiredResult = "Развитие физических качеств, уверенности в себе, освоение приёмов",
            parentInfo = "Поликарпова Наталия Анатольевна, +79858914721, АО «ПСК Монолит»"
        ),
        Update(
            currentFullName = "Вдовин Кирилл",
            address = "г. Ступино, ул. Куйбышева, 42-68",
            school = "Лицей №2, 7А класс",
            desiredResult = "Для физического развития",
            parentInfo = "Вдовин Олег Александрович, +79055675154, Ступинский химзавод; Вдовина Анастасия Сергеевна, +79037440867, магазин «Дикси», Первомайская 57"
        ),
        Update(
            currentFullName = "Вдовин Дмитрий",
            address = "г. Ступино, ул. Куйбышева, 42-68",
            school = "Ступинский лицей №2, 6В класс",
            desiredResult = "Для здоровья и физического развития",
            extraSections = "Не посещает",
            parentInfo = "Вдовин Олег Александрович, +79055675154, Ступинский химзавод; Вдовина Анастасия Сергеевна, +79037440867, магазин «Дикси», Первомайская 57"
        ),
        Update(
            currentFullName = "Курочкин Ярослав",
            address = "Московская обл., г. Ступино, ул. Первомайская, д.57, кв.39",
            school = "Школа №8, 5Б класс",
            desiredResult = "Проявление интереса к спорту",
            parentInfo = "Курочкина Олеся Вадимовна, +79263066114, ООО «ГК Альянс»"
        ),
        Update(
            currentFullName = "Горохов Архип",
            address = "Московская обл., г. Ступино, ул. Службина, д.12, кв.79",
            school = "СОШ №9, 2Д класс",
            desiredResult = "Тактические и технические навыки",
            extraSections = "Автомобили",
            parentInfo = "Горохов Павел Сергеевич, +79265441803, пенсионер"
        ),
        Update(
            currentFullName = "Кубышкин Артём",
            address = "ул. Звёздная, д.4",
            school = "Школа №8, 3 класс",
            desiredResult = "Мастер спорта",
            extraSections = "Футбол",
            parentInfo = "Кубышкин Виталий Владимирович, +79153092556, ИП Кубышкин"
        ),
        Update(
            currentFullName = "Добрынин Ярослав",
            address = "ул. Фрунзе, д.3, к.2, кв.47",
            school = "Школа №8, 3 класс",
            parentInfo = "Добрынин Владимир Вадимович, +79150078590"
        ),
        Update(
            currentFullName = "Шейхутдинов Назар",
            newFullName = "Шайхутдинов Назар",
            address = "г. Ступино",
            school = "Ступинский медицинский колледж",
            desiredResult = "Овладеть навыками самбо",
            extraSections = "Медицина",
            parentInfo = "Шайхутдинова Клара Зуфаровна, +79191052577"
        )
    )

    suspend fun importIfNeeded(database: AppDatabase, settingsRepository: SettingsRepository, forceRerun: Boolean = false) {
        if (settingsRepository.isRegistrationDataImported() && !forceRerun) return

        updates.forEach { u ->
            val existing = database.sportsmanDao().findByFullName(u.currentFullName) ?: return@forEach
            val healthText = u.healthNote?.takeIf { it.trim().lowercase() !in noRestrictionValues }

            database.sportsmanDao().update(
                existing.copy(
                    fullName = u.newFullName ?: existing.fullName,
                    address = u.address ?: existing.address,
                    schoolOrKindergarten = u.school ?: existing.schoolOrKindergarten,
                    desiredResult = u.desiredResult ?: existing.desiredResult,
                    additionalSections = u.extraSections ?: existing.additionalSections,
                    importantInformation = healthText ?: existing.importantInformation,
                    parentNotes = u.parentInfo ?: existing.parentNotes
                )
            )
        }

        settingsRepository.setRegistrationDataImported()
    }
}
