package com.sambotrainer.app.ui.sportsmen

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sambotrainer.app.data.entity.PaymentType
import com.sambotrainer.app.data.settings.SettingsRepository
import com.sambotrainer.app.domain.SubscriptionPrices

/**
 * Диалог отметки оплаты (п.13-15). Общий для карточки спортсмена и экрана
 * посещаемости — тренер может отметить оплату либо открыв конкретного
 * спортсмена, либо прямо в списке группы на "Сегодня" (без лишних переходов).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentTypeDialog(
    settingsRepository: SettingsRepository,
    sportsmanName: String? = null,
    onDismiss: () -> Unit,
    onConfirm: (PaymentType, Int, String?) -> Unit
) {
    var selected by remember { mutableStateOf(PaymentType.MONTH) }
    var expanded by remember { mutableStateOf(false) }
    var comment by remember { mutableStateOf("") }

    val monthPrice by settingsRepository.monthPrice.collectAsState(initial = SubscriptionPrices.MONTH_PRICE)
    val halfMonthPrice by settingsRepository.halfMonthPrice.collectAsState(initial = SubscriptionPrices.HALF_MONTH_PRICE)
    val singlePrice by settingsRepository.singlePrice.collectAsState(initial = SubscriptionPrices.SINGLE_PRICE)

    fun priceFor(type: PaymentType): Int = when (type) {
        PaymentType.MONTH -> monthPrice
        PaymentType.HALF_MONTH -> halfMonthPrice
        PaymentType.SINGLE -> singlePrice
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (sportsmanName != null) "Оплата — $sportsmanName" else "Отметить оплату") },
        text = {
            Column {
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(
                        value = "${SubscriptionPrices.labelFor(selected)} — ${priceFor(selected)}₽",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Тип абонемента") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        PaymentType.entries.forEach { type ->
                            DropdownMenuItem(
                                text = { Text("${SubscriptionPrices.labelFor(type)} — ${priceFor(type)}₽") },
                                onClick = { selected = type; expanded = false }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Комментарий (необязательно)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selected, priceFor(selected), comment.ifBlank { null }) }) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}
