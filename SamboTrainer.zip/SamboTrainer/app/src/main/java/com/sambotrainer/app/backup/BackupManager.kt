package com.sambotrainer.app.backup

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.sambotrainer.app.data.db.AppDatabase
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Резервное копирование и восстановление (п.42-43) — КРИТИЧЕСКИ ВАЖНО, так как
 * данные хранятся только на телефоне. Файл бэкапа — это сама база данных SQLite,
 * поэтому восстановление возвращает приложение в точности в то состояние,
 * в котором была сделана копия.
 */
object BackupManager {

    private fun timestamp(): String =
        SimpleDateFormat("yyyy-MM-dd_HHmmss", Locale.US).format(Date())

    /** Создаёт файл резервной копии в кэше приложения и возвращает его. */
    fun createBackupFile(context: Context, database: AppDatabase): File {
        // Room по умолчанию использует WAL-режим — "сбрасываем" несохранённые
        // страницы в основной файл БД перед копированием, иначе бэкап может
        // не содержать самых последних изменений.
        database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)", emptyArray()).close()

        val dbFile = context.getDatabasePath(AppDatabase.databaseFileName())
        val backupsDir = File(context.cacheDir, "backups").apply { mkdirs() }
        val backupFile = File(backupsDir, "sambo_trainer_backup_${timestamp()}.db")
        dbFile.copyTo(backupFile, overwrite = true)
        return backupFile
    }

    /** Открывает системный Android Share — Google Drive, Telegram, почта и т.д. (п.42). */
    fun shareFile(context: Context, file: File, mimeType: String = "application/octet-stream") {
        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Сохранить файл"))
    }

    /**
     * Восстанавливает БД из выбранного пользователем файла (п.43).
     * ВАЖНО: после вызова приложение необходимо перезапустить (см. restartApp) —
     * иначе уже открытые экраны будут ссылаться на закрытое соединение с БД.
     */
    fun restoreFromUri(context: Context, uri: Uri, database: AppDatabase) {
        database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)", emptyArray()).close()
        AppDatabase.closeCurrent()

        val dbFile = context.getDatabasePath(AppDatabase.databaseFileName())
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dbFile).use { output -> input.copyTo(output) }
        }
        // Удаляем старые WAL/SHM-файлы, чтобы SQLite не пытался применить к
        // восстановленной базе журнал от предыдущей (уже неактуальной) базы.
        File(dbFile.path + "-wal").delete()
        File(dbFile.path + "-shm").delete()
    }

    /** Полный перезапуск процесса приложения — нужен сразу после восстановления. */
    fun restartApp(context: Context) {
        val packageManager = context.packageManager
        val launchIntent = packageManager.getLaunchIntentForPackage(context.packageName)
        val restartIntent = Intent.makeRestartActivityTask(launchIntent?.component)
        context.startActivity(restartIntent)
        Runtime.getRuntime().exit(0)
    }
}
