package com.sambotrainer.app.ui.sportsmen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Payment
import com.sambotrainer.app.data.entity.PaymentType
import com.sambotrainer.app.data.entity.Sportsman
import com.sambotrainer.app.data.entity.SportsmanStatus
import com.sambotrainer.app.domain.AttendanceStats
import com.sambotrainer.app.domain.SportsmanAttendanceStats
import com.sambotrainer.app.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class SportsmanCardUiState(
    val sportsman: Sportsman? = null,
    val groupName: String = "",
    val stats: SportsmanAttendanceStats? = null,
    val payments: List<Payment> = emptyList()
)

class SportsmanCardViewModel(
    private val database: AppDatabase,
    private val sportsmanId: Long
) : ViewModel() {

    private val refreshTrigger = MutableStateFlow(0)

    val uiState: StateFlow<SportsmanCardUiState> = combine(
        database.sportsmanDao().observeById(sportsmanId),
        database.groupDao().observeAll(),
        database.paymentDao().observeForSportsman(sportsmanId),
        database.attendanceDao().observeForSportsman(sportsmanId),
        refreshTrigger
    ) { sportsman, groups, payments, _, _ ->
        val groupName = groups.firstOrNull { it.id == sportsman?.groupId }?.name ?: ""
        val stats = sportsman?.let { AttendanceStats.compute(database, it.id) }
        SportsmanCardUiState(
            sportsman = sportsman,
            groupName = groupName,
            stats = stats,
            payments = payments
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SportsmanCardUiState()
    )

    /** Отметить оплату за текущий месяц (п.13-15). Сумма передаётся из диалога —
     * там она берётся из редактируемых настроек цен (п.14, 47), а не из констант. */
    fun markPayment(type: PaymentType, amount: Int, comment: String?) {
        viewModelScope.launch {
            val month = DateUtils.monthKey(LocalDate.now())
            database.paymentDao().insert(
                Payment(
                    sportsmanId = sportsmanId,
                    type = type,
                    amount = amount,
                    month = month,
                    paymentDate = System.currentTimeMillis(),
                    comment = comment
                )
            )
            refreshTrigger.value += 1
        }
    }

    fun updateImportantInformation(text: String) {
        viewModelScope.launch {
            val current = database.sportsmanDao().getById(sportsmanId) ?: return@launch
            database.sportsmanDao().update(current.copy(importantInformation = text.ifBlank { null }))
        }
    }

    /** Перевести в архив, а не удалить (п.40-41). */
    fun archive() {
        viewModelScope.launch {
            database.sportsmanDao().setStatus(sportsmanId, SportsmanStatus.ARCHIVED)
        }
    }

    /** Восстановить из архива обратно в активные (п.40). */
    fun restore() {
        viewModelScope.launch {
            database.sportsmanDao().setStatus(sportsmanId, SportsmanStatus.ACTIVE)
        }
    }
}
