package com.sambotrainer.app.data.dao

import androidx.room.*
import com.sambotrainer.app.data.entity.Sportsman
import com.sambotrainer.app.data.entity.SportsmanStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface SportsmanDao {

    @Query("SELECT * FROM sportsmen WHERE status = :status ORDER BY fullName ASC")
    fun observeByStatus(status: SportsmanStatus): Flow<List<Sportsman>>

    @Query("SELECT * FROM sportsmen WHERE status = :status AND groupId = :groupId ORDER BY fullName ASC")
    fun observeByStatusAndGroup(status: SportsmanStatus, groupId: Long): Flow<List<Sportsman>>

    /** Быстрый поиск по ФИО, имени родителя, телефонам (п.20). */
    @Query(
        """
        SELECT * FROM sportsmen
        WHERE status = :status AND (
            fullName LIKE '%' || :query || '%' OR
            parentName LIKE '%' || :query || '%' OR
            parentPhone LIKE '%' || :query || '%' OR
            sportsmanPhone LIKE '%' || :query || '%'
        )
        ORDER BY fullName ASC
        """
    )
    fun search(status: SportsmanStatus, query: String): Flow<List<Sportsman>>

    @Query("SELECT * FROM sportsmen WHERE id = :id")
    fun observeById(id: Long): Flow<Sportsman?>

    @Query("SELECT * FROM sportsmen WHERE id = :id")
    suspend fun getById(id: Long): Sportsman?

    @Query("SELECT COUNT(*) FROM sportsmen WHERE fullName = :fullName AND status = :status")
    suspend fun countByFullName(fullName: String, status: SportsmanStatus = SportsmanStatus.ACTIVE): Int

    @Query("SELECT * FROM sportsmen WHERE groupId = :groupId AND status = 'ACTIVE' ORDER BY fullName ASC")
    suspend fun getActiveByGroup(groupId: Long): List<Sportsman>

    @Insert
    suspend fun insert(sportsman: Sportsman): Long

    @Update
    suspend fun update(sportsman: Sportsman)

    @Query("UPDATE sportsmen SET status = :status WHERE id = :id")
    suspend fun setStatus(id: Long, status: SportsmanStatus)

    @Delete
    suspend fun delete(sportsman: Sportsman)

    /** Полная очистка перед загрузкой реального состава поверх демо-данных (используется один раз). */
    @Query("DELETE FROM sportsmen")
    suspend fun deleteAll()

    @Query("SELECT * FROM sportsmen")
    suspend fun getAllForExport(): List<Sportsman>
}
