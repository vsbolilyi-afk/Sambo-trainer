package com.sambotrainer.app.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * Локальные Android-уведомления (п.46) — без обязательного внешнего сервера.
 * Сейчас реализовано одно уведомление: "3 занятия без оплаты" (п.16-17).
 * Архитектура позволяет добавлять новые каналы/уведомления позже, не трогая этот код.
 */
object NotificationHelper {
    private const val CHANNEL_ID = "unpaid_attendance"
    private const val CHANNEL_NAME = "Неоплаченные посещения"

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel(CHANNEL_ID) == null) {
                manager.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
        }
    }

    fun notifyUnpaidAttention(context: Context, sportsmanId: Long, sportsmanName: String) {
        ensureChannel(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Требует внимания")
            .setContentText("$sportsmanName посетил(а) 3 занятия без оплаты.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(sportsmanId.toInt(), notification)
        } catch (e: SecurityException) {
            // Разрешение POST_NOTIFICATIONS не выдано (Android 13+) — тихо игнорируем,
            // это не должно останавливать основную работу приложения (п.46).
        }
    }
}
