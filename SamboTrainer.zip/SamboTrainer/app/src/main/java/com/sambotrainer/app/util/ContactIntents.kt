package com.sambotrainer.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Быстрая связь из карточки спортсмена (п.24): звонок, SMS, Telegram, Max.
 * Тренер никогда не копирует номер вручную — одно нажатие открывает нужное приложение.
 */
object ContactIntents {

    /** Телефон -> системный экран звонка (ACTION_DIAL не требует разрешения на звонки). */
    fun call(context: Context, phone: String) {
        launchOrToast(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
    }

    /** SMS -> стандартное приложение сообщений. */
    fun sms(context: Context, phone: String) {
        launchOrToast(context, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")))
    }

    /** Telegram -> открывает диалог по username или номеру телефона. */
    fun telegram(context: Context, contact: String) {
        val uri = when {
            contact.startsWith("http") -> contact
            contact.startsWith("@") -> "https://t.me/${contact.removePrefix("@")}"
            contact.startsWith("+") || contact.all { it.isDigit() } ->
                "https://t.me/+${contact.trimStart('+')}"
            else -> "https://t.me/$contact"
        }
        launchOrToast(context, Intent(Intent.ACTION_VIEW, Uri.parse(uri)))
    }

    /**
     * Max — если приложение недоступно на устройстве, показываем сообщение и
     * рекомендуем Telegram как основной мессенджер (п.24 ТЗ).
     */
    fun max(context: Context, contact: String) {
        val launchIntent = context.packageManager.getLaunchIntentForPackage("com.max.messenger")
        if (launchIntent != null) {
            context.startActivity(launchIntent)
        } else {
            Toast.makeText(
                context,
                "Max не установлен на этом устройстве. Telegram остаётся основным мессенджером.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun launchOrToast(context: Context, intent: Intent) {
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "Не удалось открыть приложение", Toast.LENGTH_SHORT).show()
        }
    }
}
