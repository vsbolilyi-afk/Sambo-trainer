package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Навык, назначенный конкретному спортсмену из общего каталога (п.27, 28).
 * Тренер выбирает навыки индивидуально, статус переключается одним нажатием
 * 🔴 В работе -> 🟢 Освоено.
 */
@Entity(
    tableName = "sportsman_skills",
    foreignKeys = [
        ForeignKey(
            entity = Sportsman::class,
            parentColumns = ["id"],
            childColumns = ["sportsmanId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Skill::class,
            parentColumns = ["id"],
            childColumns = ["skillId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index("sportsmanId"),
        Index("skillId"),
        Index(value = ["sportsmanId", "skillId"], unique = true)
    ]
)
data class SportsmanSkill(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sportsmanId: Long,
    val skillId: Long,
    val status: SkillStatus = SkillStatus.IN_PROGRESS,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)
