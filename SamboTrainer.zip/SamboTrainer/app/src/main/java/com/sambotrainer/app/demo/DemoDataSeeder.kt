package com.sambotrainer.app.demo

import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Attendance
import com.sambotrainer.app.data.entity.AttendanceStatus
import com.sambotrainer.app.data.entity.Expense
import com.sambotrainer.app.data.entity.ExpenseType
import com.sambotrainer.app.data.entity.Note
import com.sambotrainer.app.data.entity.Payment
import com.sambotrainer.app.data.entity.PaymentType
import com.sambotrainer.app.data.entity.Skill
import com.sambotrainer.app.data.entity.SkillHistory
import com.sambotrainer.app.data.entity.SkillStatus
import com.sambotrainer.app.data.entity.Sportsman
import com.sambotrainer.app.data.entity.SportsmanSkill
import com.sambotrainer.app.domain.SubscriptionPrices
import com.sambotrainer.app.domain.TrainingSessionGenerator
import com.sambotrainer.app.util.DateUtils
import java.time.LocalDate
import kotlin.random.Random

/**
 * Демонстрационные данные при первом запуске (п.58): реалистичные посещения,
 * пропуски, оплаты, неоплаты (включая 1-2 спортсменов с 3 неоплаченными
 * посещениями — для проверки предупреждений), навыки, заметки, расходы.
 * Позволяет сразу увидеть все основные возможности приложения без ручного
 * ввода тестовых данных.
 */
object DemoDataSeeder {

    private val juniorNames = listOf(
        "Иванов Матвей", "Петров Артём", "Сидоров Дмитрий", "Кузнецов Тимофей",
        "Смирнов Егор", "Попов Максим", "Волков Кирилл", "Новиков Данила"
    )

    private val seniorNames = listOf(
        "Соколов Никита", "Морозов Иван", "Лебедев Александр", "Козлов Роман",
        "Егоров Владислав", "Захаров Глеб", "Орлов Степан", "Андреев Тимур",
        "Макаров Илья", "Никитин Богдан"
    )

    private val skillCatalog = listOf(
        "Кувырок вперёд", "Кувырок назад", "Самостраховка", "Захват",
        "Удержание сбоку", "Выход из удержания", "Бросок через бедро",
        "Подножка", "Задняя подножка"
    )

    suspend fun seedIfEmpty(database: AppDatabase) {
        val existing = database.sportsmanDao().getAllForExport()
        if (existing.isNotEmpty()) return

        val groups = database.groupDao().observeAll()
        val groupList = kotlinx.coroutines.flow.first(groups)
        val juniorGroup = groupList.firstOrNull { it.name == "Младшая" } ?: return
        val seniorGroup = groupList.firstOrNull { it.name == "Старшая" } ?: return

        // Генерируем тренировки за последние 4 недели по расписанию, чтобы было
        // на чём показать реалистичную историю посещений.
        val today = LocalDate.now()
        val fourWeeksAgo = today.minusWeeks(4)
        TrainingSessionGenerator.ensureSessionsForRange(database, fourWeeksAgo, today)

        val skillIds = skillCatalog.map { database.skillDao().insert(Skill(name = it)) }

        val juniorIds = juniorNames.map { seedSportsman(database, it, juniorGroup.id) }
        val seniorIds = seniorNames.map { seedSportsman(database, it, seniorGroup.id) }
        val allIds = juniorIds + seniorIds

        val monthKey = DateUtils.monthKey(today)

        allIds.forEachIndexed { index, sportsmanId ->
            seedAttendanceHistory(database, sportsmanId, fourWeeksAgo, today)
            seedSkills(database, sportsmanId, skillIds, index)
            seedNotes(database, sportsmanId, index)

            // Большинство оплатили текущий месяц; двое — намеренно нет (для демонстрации п.16-18).
            val isUnpaidDemo = index == 2 || index == 9
            if (!isUnpaidDemo) {
                database.paymentDao().insert(
                    Payment(
                        sportsmanId = sportsmanId,
                        type = PaymentType.MONTH,
                        amount = SubscriptionPrices.MONTH_PRICE,
                        month = monthKey,
                        paymentDate = DateUtils.toEpochDayStart(today.withDayOfMonth(1))
                    )
                )
            }
        }

        // Один ручной расход для демонстрации раздела "Финансы" (п.37).
        database.expenseDao().insert(
            Expense(
                name = "Инвентарь",
                amount = 3000,
                date = DateUtils.toEpochDayStart(today.withDayOfMonth(1)),
                type = ExpenseType.MANUAL,
                comment = "Маты для разминки"
            )
        )
    }

    private suspend fun seedSportsman(database: AppDatabase, fullName: String, groupId: Long): Long {
        val birthYear = Random.nextInt(2012, 2018)
        return database.sportsmanDao().insert(
            Sportsman(
                fullName = fullName,
                birthDate = DateUtils.toEpochDayStart(LocalDate.of(birthYear, Random.nextInt(1, 13), Random.nextInt(1, 28))),
                groupId = groupId,
                parentName = "Родитель ${fullName.substringBefore(" ")}",
                parentPhone = "+7900${Random.nextInt(1000000, 9999999)}",
                startDate = DateUtils.toEpochDayStart(LocalDate.now().minusMonths(Random.nextLong(1, 18)))
            )
        )
    }

    /** Реалистичная посещаемость за последние 4 недели, включая намеренные пропуски. */
    private suspend fun seedAttendanceHistory(database: AppDatabase, sportsmanId: Long, from: LocalDate, to: LocalDate) {
        val sportsman = database.sportsmanDao().getById(sportsmanId) ?: return
        val sessions = database.trainingSessionDao().getForRange(
            DateUtils.toEpochDayStart(from), DateUtils.toEpochDayStart(to)
        ).filter { it.groupId == sportsman.groupId }

        sessions.forEach { session ->
            // ~80% присутствие, немного пропусков, самые последние тренировки иногда не отмечены —
            // это реалистично отражает то, как тренер вводит данные день за днём.
            val status = when {
                session.date > DateUtils.toEpochDayStart(to.minusDays(2)) && Random.nextBoolean() -> AttendanceStatus.NOT_MARKED
                Random.nextInt(100) < 80 -> AttendanceStatus.PRESENT
                else -> AttendanceStatus.ABSENT
            }
            if (status != AttendanceStatus.NOT_MARKED) {
                database.attendanceDao().upsert(
                    Attendance(sportsmanId = sportsmanId, trainingSessionId = session.id, status = status)
                )
            }
        }
    }

    private suspend fun seedSkills(database: AppDatabase, sportsmanId: Long, skillIds: List<Long>, index: Int) {
        val assignedCount = 2 + (index % 3)
        val chosen = skillIds.shuffled(Random(sportsmanId)).take(assignedCount)
        chosen.forEachIndexed { i, skillId ->
            val mastered = i == 0 // первый навык у каждого — освоен, остальные в работе
            val ssId = database.sportsmanSkillDao().insert(
                SportsmanSkill(
                    sportsmanId = sportsmanId,
                    skillId = skillId,
                    status = if (mastered) SkillStatus.MASTERED else SkillStatus.IN_PROGRESS,
                    completedAt = if (mastered) System.currentTimeMillis() else null
                )
            )
            database.skillHistoryDao().insert(
                SkillHistory(
                    sportsmanSkillId = ssId,
                    date = System.currentTimeMillis(),
                    status = SkillStatus.IN_PROGRESS,
                    comment = "Навык добавлен"
                )
            )
            if (mastered) {
                database.skillHistoryDao().insert(
                    SkillHistory(sportsmanSkillId = ssId, date = System.currentTimeMillis(), status = SkillStatus.MASTERED, comment = "Освоено")
                )
            }
        }
    }

    private suspend fun seedNotes(database: AppDatabase, sportsmanId: Long, index: Int) {
        if (index % 4 == 0) {
            database.noteDao().insert(
                Note(sportsmanId = sportsmanId, date = System.currentTimeMillis(), text = "Хорошо старается на разминке, нужно больше внимания на растяжку.")
            )
        }
    }
}
