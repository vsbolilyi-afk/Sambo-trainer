package com.sambotrainer.app.demo

import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Payment
import com.sambotrainer.app.data.entity.PaymentType
import com.sambotrainer.app.data.entity.Sportsman
import com.sambotrainer.app.data.settings.SettingsRepository
import com.sambotrainer.app.util.DateUtils
import kotlinx.coroutines.flow.first
import java.time.LocalDate

/**
 * Загрузка реального состава спортивной школы (заменяет прежние вымышленные
 * демо-данные). Прогоняется РОВНО ОДИН РАЗ — отслеживается флагом
 * SettingsRepository.isRealRosterSeeded(), поэтому повторные обновления
 * приложения не затрут данные, которые тренер уже отредактировал.
 *
 * Дата рождения не была передана тренером, поэтому проставлена условная
 * заглушка (01.01.2013) — её нужно будет поправить вручную в карточке
 * спортсмена, когда появится экран редактирования существующих данных.
 */
data class RosterEntry(
    val fullName: String,
    val amount: Int? = null,
    val type: PaymentType? = null,
    val monthsAgo: Int = 0, // 0 = текущий месяц, 1 = прошлый месяц
    val comment: String? = null
)

object DemoDataSeeder {

    private val senior = listOf(
        RosterEntry("Шейхутдинов Назар", 4500, PaymentType.MONTH),
        RosterEntry("Богданов Тихон", 4500, PaymentType.MONTH),
        RosterEntry("Богданов Гордей", 4500, PaymentType.MONTH),
        RosterEntry("Карапунарлы Михаил"),
        RosterEntry("Карапунарлы Дмитрий"),
        RosterEntry("Болилый Иван", 0, PaymentType.SINGLE, comment = "Не оплачивает — без взноса"),
        RosterEntry("Чулков Иван", 3500, PaymentType.HALF_MONTH),
        RosterEntry("Добрынин Ярослав"),
        RosterEntry("Кубышкин Артём", 3500, PaymentType.HALF_MONTH),
        RosterEntry("Дуйшокеев Амир", 4500, PaymentType.MONTH, monthsAgo = 1, comment = "Оплата за прошлый месяц"),
        RosterEntry("Плакунов Богдан"),
        RosterEntry("Вдовин Кирилл", 4500, PaymentType.MONTH),
        RosterEntry("Вдовин Дмитрий", 4500, PaymentType.MONTH),
        RosterEntry("Поликарпов Максим"),
        RosterEntry("Турбаев Арсений"),
        RosterEntry("Турбаев Савелий"),
        RosterEntry("Ивахнин Константин", 3500, PaymentType.HALF_MONTH),
        RosterEntry("Казаков Александр"),
        RosterEntry("Горохов Архип", 4500, PaymentType.MONTH)
    )

    private val junior = listOf(
        RosterEntry("Шошин Ярослав"),
        RosterEntry("Михальчев Егор", 3500, PaymentType.HALF_MONTH),
        RosterEntry("Есюнин Алексей", 4500, PaymentType.MONTH),
        RosterEntry("Нефедьев Антон", 4500, PaymentType.MONTH),
        RosterEntry("Ребров Николай", 4500, PaymentType.MONTH),
        RosterEntry("Шейхутдинов Роберт", 4500, PaymentType.MONTH),
        RosterEntry("Деев Марк", 4500, PaymentType.MONTH),
        RosterEntry("Курочкин Ярослав", 4500, PaymentType.MONTH),
        RosterEntry("Лёва", comment = "Новый участник, фамилия не указана"),
        RosterEntry("Юдинцев Арсений", 4500, PaymentType.MONTH),
        RosterEntry("Чесных Серафим", comment = "Новый участник")
    )

    suspend fun seedIfEmpty(database: AppDatabase, settingsRepository: SettingsRepository) {
        if (settingsRepository.isRealRosterSeeded()) return

        // Если раньше уже успели создаться прежние вымышленные демо-спортсмены —
        // безопасно удаляем их (посещения/оплаты/навыки/заметки удалятся каскадно)
        // и загружаем настоящий состав.
        database.sportsmanDao().deleteAll()

        val groupList = database.groupDao().observeAll().first()
        val juniorGroup = groupList.firstOrNull { it.name == "Младшая" }
        val seniorGroup = groupList.firstOrNull { it.name == "Старшая" }

        if (juniorGroup != null) {
            junior.forEach { entry -> insertEntry(database, entry, juniorGroup.id) }
        }
        if (seniorGroup != null) {
            senior.forEach { entry -> insertEntry(database, entry, seniorGroup.id) }
        }

        settingsRepository.setRealRosterSeeded()
    }

    private suspend fun insertEntry(database: AppDatabase, entry: RosterEntry, groupId: Long) {
        val placeholderBirthDate = DateUtils.toEpochDayStart(LocalDate.of(2013, 1, 1))
        val sportsmanId = database.sportsmanDao().insert(
            Sportsman(
                fullName = entry.fullName,
                birthDate = placeholderBirthDate,
                groupId = groupId,
                importantInformation = entry.comment?.takeIf { entry.amount == null && entry.monthsAgo == 0 }
            )
        )

        if (entry.amount != null && entry.type != null) {
            val month = LocalDate.now().minusMonths(entry.monthsAgo.toLong())
            database.paymentDao().insert(
                Payment(
                    sportsmanId = sportsmanId,
                    type = entry.type,
                    amount = entry.amount,
                    month = DateUtils.monthKey(month),
                    paymentDate = DateUtils.toEpochDayStart(month.withDayOfMonth(1)),
                    comment = entry.comment
                )
            )
        }
    }
}
