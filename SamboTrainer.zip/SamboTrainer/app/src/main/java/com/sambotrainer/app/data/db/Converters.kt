package com.sambotrainer.app.data.db

import androidx.room.TypeConverter
import com.sambotrainer.app.data.entity.AttendanceStatus
import com.sambotrainer.app.data.entity.ExpenseType
import com.sambotrainer.app.data.entity.PaymentType
import com.sambotrainer.app.data.entity.SkillStatus
import com.sambotrainer.app.data.entity.SportsmanStatus

/** Room хранит enum-типы как их имя (String) — просто и надёжно для миграций (п.54). */
class Converters {

    @TypeConverter
    fun fromSportsmanStatus(v: SportsmanStatus): String = v.name
    @TypeConverter
    fun toSportsmanStatus(v: String): SportsmanStatus = SportsmanStatus.valueOf(v)

    @TypeConverter
    fun fromAttendanceStatus(v: AttendanceStatus): String = v.name
    @TypeConverter
    fun toAttendanceStatus(v: String): AttendanceStatus = AttendanceStatus.valueOf(v)

    @TypeConverter
    fun fromPaymentType(v: PaymentType): String = v.name
    @TypeConverter
    fun toPaymentType(v: String): PaymentType = PaymentType.valueOf(v)

    @TypeConverter
    fun fromSkillStatus(v: SkillStatus): String = v.name
    @TypeConverter
    fun toSkillStatus(v: String): SkillStatus = SkillStatus.valueOf(v)

    @TypeConverter
    fun fromExpenseType(v: ExpenseType): String = v.name
    @TypeConverter
    fun toExpenseType(v: String): ExpenseType = ExpenseType.valueOf(v)
}
