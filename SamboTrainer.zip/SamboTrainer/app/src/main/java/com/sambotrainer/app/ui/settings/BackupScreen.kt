package com.sambotrainer.app.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.sambotrainer.app.backup.BackupManager
import com.sambotrainer.app.backup.ExportManager
import com.sambotrainer.app.backup.WorkScheduler
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.settings.SettingsRepository
import kotlinx.coroutines.launch

@Composable
fun BackupScreen(database: AppDatabase, settingsRepository: SettingsRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingRestoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var showRestartHint by remember { mutableStateOf(false) }

    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingRestoreUri = uri
    }

    val autoBackup by settingsRepository.autoBackup.collectAsState(initial = "off")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Резервное копирование") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            Text(
                "Все данные приложения хранятся только на этом телефоне. Регулярно " +
                    "создавайте резервную копию, чтобы не потерять их.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    val file = BackupManager.createBackupFile(context, database)
                    BackupManager.shareFile(context, file)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Создать резервную копию") }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = { restoreLauncher.launch(arrayOf("*/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Восстановить из резервной копии") }

            Spacer(modifier = Modifier.height(28.dp))
            Text("Автоматическая копия", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Создавать копию раз в неделю", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Сохраняется автоматически на телефоне, хранятся последние 5 копий",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = autoBackup == "weekly",
                    onCheckedChange = { checked ->
                        val newValue = if (checked) "weekly" else "off"
                        scope.launch { settingsRepository.setAutoBackup(newValue) }
                        WorkScheduler.syncWithSetting(context, newValue)
                    }
                )
            }

            Spacer(modifier = Modifier.height(28.dp))
            Text("Экспорт данных", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = {
                    scope.launch {
                        val file = ExportManager.exportJson(context, database)
                        BackupManager.shareFile(context, file, "application/json")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Экспортировать в JSON") }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = {
                    scope.launch {
                        val file = ExportManager.exportCsv(context, database)
                        BackupManager.shareFile(context, file, "text/csv")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Экспортировать в CSV") }
        }
    }

    pendingRestoreUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestoreUri = null },
            title = { Text("Восстановить данные?") },
            text = { Text("Текущие данные будут заменены данными из резервной копии. Это действие нельзя отменить.") },
            confirmButton = {
                TextButton(onClick = {
                    BackupManager.restoreFromUri(context, uri, database)
                    pendingRestoreUri = null
                    showRestartHint = true
                }) { Text("Восстановить") }
            },
            dismissButton = {
                TextButton(onClick = { pendingRestoreUri = null }) { Text("Отмена") }
            }
        )
    }

    if (showRestartHint) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("Данные восстановлены") },
            text = { Text("Чтобы изменения применились, приложение нужно перезапустить.") },
            confirmButton = {
                TextButton(onClick = { BackupManager.restartApp(context) }) { Text("Перезапустить") }
            }
        )
    }
}
