package com.sambotrainer.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Sportsman
import com.sambotrainer.app.data.entity.SportsmanStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private class ArchiveViewModel(private val database: AppDatabase) : ViewModel() {
    val archived = database.sportsmanDao().observeByStatus(SportsmanStatus.ARCHIVED)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun restore(sportsman: Sportsman) {
        viewModelScope.launch { database.sportsmanDao().setStatus(sportsman.id, SportsmanStatus.ACTIVE) }
    }

    /** Физическое удаление (п.41) — необратимо, вызывается только после двойного подтверждения на экране. */
    fun deletePermanently(sportsman: Sportsman) {
        viewModelScope.launch { database.sportsmanDao().delete(sportsman) }
    }
}

@Composable
fun ArchiveScreen(database: AppDatabase, onBack: () -> Unit) {
    val viewModel: ArchiveViewModel = viewModel(factory = viewModelFactory { initializer { ArchiveViewModel(database) } })
    val archived by viewModel.archived.collectAsState()

    var deleteStep1Target by remember { mutableStateOf<Sportsman?>(null) }
    var deleteStep2Target by remember { mutableStateOf<Sportsman?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Архив спортсменов") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 12.dp)) {
            if (archived.isEmpty()) {
                Text("В архиве пока никого нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text(
                    "Спортсмены из архива не участвуют в тренировках и финансах, но их данные сохранены.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(4.dp))
                LazyColumn {
                    items(archived, key = { it.id }) { sportsman ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(sportsman.fullName, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                TextButton(onClick = { viewModel.restore(sportsman) }) { Text("Восстановить") }
                                TextButton(onClick = { deleteStep1Target = sportsman }) {
                                    Text("Удалить навсегда", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Шаг 1 подтверждения
    deleteStep1Target?.let { sportsman ->
        AlertDialog(
            onDismissRequest = { deleteStep1Target = null },
            title = { Text("Удалить «${sportsman.fullName}» навсегда?") },
            text = { Text("Будут безвозвратно удалены все посещения, оплаты, навыки и заметки этого спортсмена. Отменить это действие нельзя.") },
            confirmButton = {
                TextButton(onClick = {
                    deleteStep1Target = null
                    deleteStep2Target = sportsman
                }) { Text("Продолжить") }
            },
            dismissButton = { TextButton(onClick = { deleteStep1Target = null }) { Text("Отмена") } }
        )
    }

    // Шаг 2 — финальное подтверждение (двойная защита от случайного нажатия, п.41).
    deleteStep2Target?.let { sportsman ->
        AlertDialog(
            onDismissRequest = { deleteStep2Target = null },
            title = { Text("Вы точно уверены?") },
            text = { Text("Это последнее предупреждение. «${sportsman.fullName}» и все его данные исчезнут окончательно.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deletePermanently(sportsman)
                    deleteStep2Target = null
                }) { Text("Удалить окончательно", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleteStep2Target = null }) { Text("Отмена") } }
        )
    }
}
