package com.sambotrainer.app.data.dao

import androidx.room.*
import com.sambotrainer.app.data.entity.Group
import kotlinx.coroutines.flow.Flow

@Dao
interface GroupDao {
    @Query("SELECT * FROM groups ORDER BY name ASC")
    fun observeAll(): Flow<List<Group>>

    @Query("SELECT * FROM groups WHERE active = 1 ORDER BY name ASC")
    fun observeActive(): Flow<List<Group>>

    @Query("SELECT * FROM groups WHERE id = :id")
    suspend fun getById(id: Long): Group?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(group: Group): Long

    @Update
    suspend fun update(group: Group)

    @Delete
    suspend fun delete(group: Group)
}
