package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * История прогресса по навыку (п.29): комментарии тренера с датами,
 * например "Выполняет только с помощью" -> "Начал выполнять самостоятельно" -> "Освоено".
 */
@Entity(
    tableName = "skill_history",
    foreignKeys = [
        ForeignKey(
            entity = SportsmanSkill::class,
            parentColumns = ["id"],
            childColumns = ["sportsmanSkillId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sportsmanSkillId")]
)
data class SkillHistory(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sportsmanSkillId: Long,
    val date: Long,
    val status: SkillStatus,
    val comment: String? = null
)
