package com.sambotrainer.app.data.dao

import androidx.room.*
import com.sambotrainer.app.data.entity.Expense
import com.sambotrainer.app.data.entity.ExpenseType
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {

    @Query("SELECT * FROM expenses WHERE date >= :from AND date <= :to ORDER BY date DESC")
    fun observeForRange(from: Long, to: Long): Flow<List<Expense>>

    @Query("SELECT * FROM expenses WHERE date >= :from AND date <= :to")
    suspend fun getForRange(from: Long, to: Long): List<Expense>

    @Query("SELECT COUNT(*) FROM expenses WHERE type = :type AND date >= :from AND date <= :to")
    suspend fun countAutoForRange(from: Long, to: Long, type: ExpenseType = ExpenseType.RENT): Int

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE date >= :from AND date <= :to")
    fun observeTotalForRange(from: Long, to: Long): Flow<Int>

    @Insert
    suspend fun insert(expense: Expense): Long

    @Update
    suspend fun update(expense: Expense)

    @Delete
    suspend fun delete(expense: Expense)

    /** Удалить старый авто-расход аренды перед пересчётом за месяц (п.36). */
    @Query("DELETE FROM expenses WHERE type = 'RENT' AND date >= :from AND date <= :to")
    suspend fun deleteRentForRange(from: Long, to: Long)

    @Query("SELECT * FROM expenses")
    suspend fun getAllForExport(): List<Expense>
}
