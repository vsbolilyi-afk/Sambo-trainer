package com.sambotrainer.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Today
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Пять основных разделов нижней навигации (п.7). Больше разделов не добавляем —
 * это прямое требование ТЗ.
 */
sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Today : Screen("today", "Сегодня", Icons.Filled.Today)
    object Sportsmen : Screen("sportsmen", "Спортсмены", Icons.Filled.Groups)
    object Calendar : Screen("calendar", "Календарь", Icons.Filled.CalendarMonth)
    object Payments : Screen("payments", "Оплаты", Icons.Filled.Payments)
    object More : Screen("more", "Ещё", Icons.Filled.MoreHoriz)

    companion object {
        val bottomBarItems = listOf(Today, Sportsmen, Calendar, Payments, More)
    }
}

/** Маршруты детальных экранов, открывающихся поверх нижней навигации. */
object DetailRoutes {
    const val SPORTSMAN_CARD = "sportsmanCard/{sportsmanId}"
    const val ATTENDANCE = "attendance/{sessionId}"
    const val ADD_SPORTSMAN = "addSportsman"
    const val EDIT_SPORTSMAN = "editSportsman/{sportsmanId}"
    const val SETTINGS_SCHEDULE = "settings/schedule"
    const val SETTINGS_GROUPS = "settings/groups"
    const val SETTINGS_SKILLS = "settings/skills"
    const val SETTINGS_PRICES = "settings/prices"
    const val SETTINGS_BACKUP = "settings/backup"
    const val SETTINGS_ABOUT = "settings/about"
    const val SETTINGS_NOTIFICATIONS = "settings/notifications"
    const val SETTINGS_ARCHIVE = "settings/archive"

    fun sportsmanCard(sportsmanId: Long) = "sportsmanCard/$sportsmanId"
    fun attendance(sessionId: Long) = "attendance/$sessionId"
    fun editSportsman(sportsmanId: Long) = "editSportsman/$sportsmanId"
}
