package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Запись об оплате (п.13-15, 56).
 * month хранится в формате "YYYY-MM" — оплата всегда относится к
 * конкретному календарному месяцу (п.13).
 */
@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = Sportsman::class,
            parentColumns = ["id"],
            childColumns = ["sportsmanId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sportsmanId"), Index("month")]
)
data class Payment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sportsmanId: Long,
    val type: PaymentType,
    val amount: Int,          // сумма в рублях
    val month: String,        // "YYYY-MM"
    val paymentDate: Long,    // дата фактической оплаты, epoch millis
    val comment: String? = null
)
