package com.sambotrainer.app.backup

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.sambotrainer.app.SamboTrainerApp

/**
 * Фоновая задача автоматического резервного копирования (п.45).
 * Запускается по расписанию через WorkManager (см. WorkScheduler) —
 * работает даже если приложение не открыто, при условии что оно
 * не выгружено системой полностью (обычное поведение Android для WorkManager).
 */
class AutoBackupWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val app = applicationContext as SamboTrainerApp
            BackupManager.createAutoBackup(applicationContext, app.database)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
