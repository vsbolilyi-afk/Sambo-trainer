package com.sambotrainer.app.domain

import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.AttendanceStatus
import com.sambotrainer.app.util.DateUtils
import java.time.LocalDate

/** Порог посещений без оплаты, после которого спортсмен требует внимания (п.16). */
const val UNPAID_ATTENTION_THRESHOLD = 3

data class SportsmanAttendanceStats(
    val paidThisMonth: Boolean,
    val unpaidPresentCountThisMonth: Int,
    val needsAttention: Boolean,
    val totalPresent: Int,
    val totalAbsent: Int,
    val attendancePercent: Int
)

object AttendanceStats {

    /**
     * Считает статистику посещений/оплаты спортсмена за текущий месяц (п.16)
     * и общую статистику посещаемости за всё время (п.23).
     */
    suspend fun compute(database: AppDatabase, sportsmanId: Long, month: LocalDate = LocalDate.now()): SportsmanAttendanceStats {
        val monthKey = DateUtils.monthKey(month)
        val paidThisMonth = database.paymentDao().getForSportsmanMonth(sportsmanId, monthKey).isNotEmpty()

        val monthStart = DateUtils.toEpochDayStart(month.withDayOfMonth(1))
        val monthEnd = DateUtils.toEpochDayStart(month.withDayOfMonth(month.lengthOfMonth()))

        val presentThisMonth = database.attendanceDao().getForSportsmanInRangeWithStatus(
            sportsmanId, AttendanceStatus.PRESENT, monthStart, monthEnd
        ).size

        // Предупреждение исчезает сразу после оплаты (п.18), но счётчик посещений
        // без оплаты как исторический факт не удаляется — он просто перестаёт быть "требующим внимания".
        val needsAttention = !paidThisMonth && presentThisMonth >= UNPAID_ATTENTION_THRESHOLD

        val allAttendance = database.attendanceDao().getForSportsman(sportsmanId)
        val totalPresent = allAttendance.count { it.status == AttendanceStatus.PRESENT }
        val totalAbsent = allAttendance.count { it.status == AttendanceStatus.ABSENT }
        val totalMarked = totalPresent + totalAbsent
        val percent = if (totalMarked > 0) (totalPresent * 100 / totalMarked) else 0

        return SportsmanAttendanceStats(
            paidThisMonth = paidThisMonth,
            unpaidPresentCountThisMonth = presentThisMonth,
            needsAttention = needsAttention,
            totalPresent = totalPresent,
            totalAbsent = totalAbsent,
            attendancePercent = percent
        )
    }
}
