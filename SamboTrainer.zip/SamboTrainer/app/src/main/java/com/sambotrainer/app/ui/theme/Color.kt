package com.sambotrainer.app.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Премиальная светлая палитра (п.49): тёплый белый фон вместо чистого белого,
 * почти чёрный текст/кнопки в духе iOS, один сдержанный акцентный синий —
 * без ярких контрастных цветов "как в детском приложении".
 */
object AppColors {
    val Ink = Color(0xFF0B0B0D)           // основной текст, кнопки — почти чёрный
    val InkSecondary = Color(0xFF6E6E76)  // вторичный текст — приглушённый серый
    val Accent = Color(0xFF3B63F2)        // единственный яркий акцент — синий
    val AccentOnLight = Color(0xFF1F3FB0)

    val Background = Color(0xFFF6F5F2)    // тёплый почти-белый фон экрана
    val Surface = Color(0xFFFFFFFF)       // карточки поверх фона
    val SurfaceVariant = Color(0xFFECEAE4) // "матовое стекло" — полупрозрачные карточки
    val Outline = Color(0xFFDEDCD5)

    val Success = Color(0xFF1C8A4B)
    val SuccessBg = Color(0xFFE3F3E9)
    val Danger = Color(0xFFD8392C)
    val DangerBg = Color(0xFFFBEAE8)
}
