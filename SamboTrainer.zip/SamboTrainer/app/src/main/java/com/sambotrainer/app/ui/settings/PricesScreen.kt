package com.sambotrainer.app.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sambotrainer.app.data.settings.SettingsRepository
import kotlinx.coroutines.launch

@Composable
fun PricesScreen(settingsRepository: SettingsRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()

    val monthPriceFlow by settingsRepository.monthPrice.collectAsState(initial = 4500)
    val halfMonthPriceFlow by settingsRepository.halfMonthPrice.collectAsState(initial = 3500)
    val singlePriceFlow by settingsRepository.singlePrice.collectAsState(initial = 600)
    val rentFlow by settingsRepository.rentPerDay.collectAsState(initial = 1500)

    var monthPrice by remember { mutableStateOf(monthPriceFlow.toString()) }
    var halfMonthPrice by remember { mutableStateOf(halfMonthPriceFlow.toString()) }
    var singlePrice by remember { mutableStateOf(singlePriceFlow.toString()) }
    var rent by remember { mutableStateOf(rentFlow.toString()) }

    LaunchedEffect(monthPriceFlow) { monthPrice = monthPriceFlow.toString() }
    LaunchedEffect(halfMonthPriceFlow) { halfMonthPrice = halfMonthPriceFlow.toString() }
    LaunchedEffect(singlePriceFlow) { singlePrice = singlePriceFlow.toString() }
    LaunchedEffect(rentFlow) { rent = rentFlow.toString() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Абонементы и аренда") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            Text("Цены абонементов, ₽", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(monthPrice, { monthPrice = it.filter { c -> c.isDigit() } }, label = { Text("Месяц (3 занятия/неделю)") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(halfMonthPrice, { halfMonthPrice = it.filter { c -> c.isDigit() } }, label = { Text("Полмесяца") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(singlePrice, { singlePrice = it.filter { c -> c.isDigit() } }, label = { Text("Разовое занятие") }, modifier = Modifier.fillMaxWidth())

            Spacer(modifier = Modifier.height(24.dp))
            Text("Аренда, ₽ за тренировочный день", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(rent, { rent = it.filter { c -> c.isDigit() } }, label = { Text("Стоимость аренды") }, modifier = Modifier.fillMaxWidth())

            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = {
                    scope.launch {
                        monthPrice.toIntOrNull()?.let { settingsRepository.setMonthPrice(it) }
                        halfMonthPrice.toIntOrNull()?.let { settingsRepository.setHalfMonthPrice(it) }
                        singlePrice.toIntOrNull()?.let { settingsRepository.setSinglePrice(it) }
                        rent.toIntOrNull()?.let { settingsRepository.setRentPerDay(it) }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Сохранить") }
        }
    }
}
