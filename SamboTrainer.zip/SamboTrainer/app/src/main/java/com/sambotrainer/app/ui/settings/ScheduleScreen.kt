package com.sambotrainer.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Group
import com.sambotrainer.app.data.entity.Schedule
import com.sambotrainer.app.util.DateUtils
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private class ScheduleViewModel(private val database: AppDatabase) : ViewModel() {
    val groups = database.groupDao().observeActive()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val schedule = database.scheduleDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(groupId: Long, weekday: Int, start: Int, end: Int) {
        viewModelScope.launch {
            database.scheduleDao().insert(Schedule(groupId = groupId, weekday = weekday, startMinuteOfDay = start, endMinuteOfDay = end))
        }
    }

    fun toggleActive(item: Schedule) {
        viewModelScope.launch { database.scheduleDao().update(item.copy(active = !item.active)) }
    }

    fun delete(item: Schedule) {
        viewModelScope.launch { database.scheduleDao().delete(item) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleScreen(database: AppDatabase, onBack: () -> Unit) {
    val viewModel: ScheduleViewModel = viewModel(factory = viewModelFactory { initializer { ScheduleViewModel(database) } })
    val groups by viewModel.groups.collectAsState()
    val schedule by viewModel.schedule.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Расписание") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Filled.Add, contentDescription = "Добавить") }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 12.dp)) {
            if (schedule.isEmpty()) {
                Text("Расписание пустое", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val groupsById = groups.associateBy { it.id }
                LazyColumn {
                    items(schedule, key = { it.id }) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("${groupsById[item.groupId]?.name ?: "Группа"} · ${DateUtils.weekdayLabel(item.weekday)}", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "${DateUtils.formatMinuteOfDay(item.startMinuteOfDay)}–${DateUtils.formatMinuteOfDay(item.endMinuteOfDay)}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(checked = item.active, onCheckedChange = { viewModel.toggleActive(item) })
                                    IconButton(onClick = { viewModel.delete(item) }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Удалить")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddScheduleDialog(
            groups = groups,
            onDismiss = { showAdd = false },
            onSave = { groupId, weekday, start, end ->
                viewModel.add(groupId, weekday, start, end)
                showAdd = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddScheduleDialog(
    groups: List<Group>,
    onDismiss: () -> Unit,
    onSave: (Long, Int, Int, Int) -> Unit
) {
    var selectedGroupId by remember { mutableStateOf(groups.firstOrNull()?.id) }
    var groupExpanded by remember { mutableStateOf(false) }
    var weekday by remember { mutableStateOf(1) }
    var weekdayExpanded by remember { mutableStateOf(false) }
    var startText by remember { mutableStateOf("17:00") }
    var endText by remember { mutableStateOf("18:30") }

    fun parseMinutes(text: String): Int? {
        val parts = text.split(":")
        if (parts.size != 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        if (h !in 0..23 || m !in 0..59) return null
        return h * 60 + m
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новое занятие") },
        text = {
            Column {
                ExposedDropdownMenuBox(expanded = groupExpanded, onExpandedChange = { groupExpanded = it }) {
                    OutlinedTextField(
                        value = groups.firstOrNull { it.id == selectedGroupId }?.name ?: "",
                        onValueChange = {}, readOnly = true, label = { Text("Группа") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = groupExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    DropdownMenu(expanded = groupExpanded, onDismissRequest = { groupExpanded = false }) {
                        groups.forEach { g ->
                            DropdownMenuItem(text = { Text(g.name) }, onClick = { selectedGroupId = g.id; groupExpanded = false })
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                ExposedDropdownMenuBox(expanded = weekdayExpanded, onExpandedChange = { weekdayExpanded = it }) {
                    OutlinedTextField(
                        value = DateUtils.weekdayLabel(weekday),
                        onValueChange = {}, readOnly = true, label = { Text("День недели") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = weekdayExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    DropdownMenu(expanded = weekdayExpanded, onDismissRequest = { weekdayExpanded = false }) {
                        (1..7).forEach { d ->
                            DropdownMenuItem(text = { Text(DateUtils.weekdayLabel(d)) }, onClick = { weekday = d; weekdayExpanded = false })
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row {
                    OutlinedTextField(value = startText, onValueChange = { startText = it }, label = { Text("Начало (ЧЧ:ММ)") }, modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.height(0.dp))
                    OutlinedTextField(value = endText, onValueChange = { endText = it }, label = { Text("Конец (ЧЧ:ММ)") }, modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val start = parseMinutes(startText)
                val end = parseMinutes(endText)
                val groupId = selectedGroupId
                if (start != null && end != null && groupId != null && end > start) {
                    onSave(groupId, weekday, start, end)
                }
            }) { Text("Добавить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
