package com.sambotrainer.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.ui.common.PlaceholderScreen
import com.sambotrainer.app.ui.navigation.Screen
import com.sambotrainer.app.ui.today.TodayScreen

/**
 * Корень UI приложения: нижняя навигация из 5 разделов (п.7) + NavHost.
 * В этой фазе полностью реализован только "Сегодня"; остальные — заглушки,
 * которые будут заменены в следующих фазах без изменения структуры навигации.
 */
@Composable
fun SamboTrainerRoot(database: AppDatabase) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination?.route

            NavigationBar {
                Screen.bottomBarItems.forEach { screen ->
                    NavigationBarItem(
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Today.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Today.route) {
                TodayScreen(
                    database = database,
                    onSessionClick = { /* Фаза 3: экран посещаемости тренировки */ }
                )
            }
            composable(Screen.Sportsmen.route) {
                PlaceholderScreen(Screen.Sportsmen.label)
            }
            composable(Screen.Calendar.route) {
                PlaceholderScreen(Screen.Calendar.label)
            }
            composable(Screen.Payments.route) {
                PlaceholderScreen(Screen.Payments.label)
            }
            composable(Screen.More.route) {
                PlaceholderScreen(Screen.More.label)
            }
        }
    }
}
