package com.sambotrainer.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.navArgument
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.settings.SettingsRepository
import com.sambotrainer.app.ui.attendance.AttendanceScreen
import com.sambotrainer.app.ui.calendar.CalendarScreen
import com.sambotrainer.app.ui.finance.FinanceScreen
import com.sambotrainer.app.ui.navigation.DetailRoutes
import com.sambotrainer.app.ui.navigation.Screen
import com.sambotrainer.app.ui.settings.AboutScreen
import com.sambotrainer.app.ui.settings.BackupScreen
import com.sambotrainer.app.ui.settings.GroupsScreen
import com.sambotrainer.app.ui.settings.MoreMenuScreen
import com.sambotrainer.app.ui.settings.PricesScreen
import com.sambotrainer.app.ui.settings.ScheduleScreen
import com.sambotrainer.app.ui.settings.SkillsCatalogScreen
import com.sambotrainer.app.ui.sportsmen.AddSportsmanScreen
import com.sambotrainer.app.ui.sportsmen.SportsmanCardScreen
import com.sambotrainer.app.ui.sportsmen.SportsmenListScreen
import com.sambotrainer.app.ui.today.TodayScreen

/**
 * Корень UI приложения: нижняя навигация из 5 разделов (п.7) + NavHost со всеми
 * детальными экранами, накопленными за Фазы 1-7.
 */
@Composable
fun SamboTrainerRoot(database: AppDatabase, settingsRepository: SettingsRepository) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination?.route

            NavigationBar {
                Screen.bottomBarItems.forEach { screen ->
                    NavigationBarItem(
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Today.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Today.route) {
                TodayScreen(
                    database = database,
                    onSessionClick = { sessionId ->
                        navController.navigate(DetailRoutes.attendance(sessionId))
                    }
                )
            }

            composable(Screen.Sportsmen.route) {
                SportsmenListScreen(
                    database = database,
                    onSportsmanClick = { id -> navController.navigate(DetailRoutes.sportsmanCard(id)) },
                    onAddClick = { navController.navigate(DetailRoutes.ADD_SPORTSMAN) }
                )
            }

            composable(Screen.Calendar.route) {
                CalendarScreen(
                    database = database,
                    onSessionClick = { sessionId -> navController.navigate(DetailRoutes.attendance(sessionId)) }
                )
            }

            composable(Screen.Payments.route) {
                FinanceScreen(database = database, settingsRepository = settingsRepository)
            }

            composable(Screen.More.route) {
                MoreMenuScreen(onNavigate = { route -> navController.navigate(route) })
            }

            composable(
                route = DetailRoutes.SPORTSMAN_CARD,
                arguments = listOf(navArgument("sportsmanId") { type = NavType.LongType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getLong("sportsmanId") ?: return@composable
                SportsmanCardScreen(
                    database = database,
                    settingsRepository = settingsRepository,
                    sportsmanId = id,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = DetailRoutes.ATTENDANCE,
                arguments = listOf(navArgument("sessionId") { type = NavType.LongType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getLong("sessionId") ?: return@composable
                AttendanceScreen(
                    database = database,
                    sessionId = id,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(DetailRoutes.ADD_SPORTSMAN) {
                AddSportsmanScreen(
                    database = database,
                    onBack = { navController.popBackStack() },
                    onSaved = { id ->
                        navController.popBackStack()
                        navController.navigate(DetailRoutes.sportsmanCard(id))
                    }
                )
            }

            composable(DetailRoutes.SETTINGS_SCHEDULE) {
                ScheduleScreen(database = database, onBack = { navController.popBackStack() })
            }
            composable(DetailRoutes.SETTINGS_GROUPS) {
                GroupsScreen(database = database, onBack = { navController.popBackStack() })
            }
            composable(DetailRoutes.SETTINGS_SKILLS) {
                SkillsCatalogScreen(database = database, onBack = { navController.popBackStack() })
            }
            composable(DetailRoutes.SETTINGS_PRICES) {
                PricesScreen(settingsRepository = settingsRepository, onBack = { navController.popBackStack() })
            }
            composable(DetailRoutes.SETTINGS_BACKUP) {
                BackupScreen(database = database, onBack = { navController.popBackStack() })
            }
            composable(DetailRoutes.SETTINGS_ABOUT) {
                AboutScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
