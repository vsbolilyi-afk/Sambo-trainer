package com.sambotrainer.app.backup

import android.content.Context
import com.google.gson.GsonBuilder
import com.sambotrainer.app.data.db.AppDatabase
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Экспорт данных без интернета (п.44): JSON — полный резервный файл в читаемом
 * виде, CSV — для просмотра списков в Excel/Google Таблицах.
 */
object ExportManager {

    private fun timestamp(): String =
        SimpleDateFormat("yyyy-MM-dd_HHmmss", Locale.US).format(Date())

    suspend fun exportJson(context: Context, database: AppDatabase): File {
        val payload = mapOf(
            "sportsmen" to database.sportsmanDao().getAllForExport(),
            "payments" to database.paymentDao().getAllForExport(),
            "expenses" to database.expenseDao().getAllForExport()
        )
        val json = GsonBuilder().setPrettyPrinting().create().toJson(payload)
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "sambo_trainer_export_${timestamp()}.json")
        file.writeText(json)
        return file
    }

    suspend fun exportCsv(context: Context, database: AppDatabase): File {
        val sportsmen = database.sportsmanDao().getAllForExport()
        val payments = database.paymentDao().getAllForExport()

        val sb = StringBuilder()
        sb.appendLine("Спортсмены")
        sb.appendLine("ФИО;Группа;Родитель;Телефон родителя;Статус")
        sportsmen.forEach { s ->
            sb.appendLine("${s.fullName};${s.groupId};${s.parentName ?: ""};${s.parentPhone ?: ""};${s.status}")
        }
        sb.appendLine()
        sb.appendLine("Оплаты")
        sb.appendLine("Спортсмен ID;Месяц;Сумма;Тип;Дата")
        payments.forEach { p ->
            sb.appendLine("${p.sportsmanId};${p.month};${p.amount};${p.type};${p.paymentDate}")
        }

        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "sambo_trainer_export_${timestamp()}.csv")
        file.writeText(sb.toString())
        return file
    }
}
