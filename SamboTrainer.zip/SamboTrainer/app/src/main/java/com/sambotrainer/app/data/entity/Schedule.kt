package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Строка расписания группы (п.9). Не зашита в код — полностью редактируется
 * тренером в разделе "Ещё → Расписание".
 * startTime / endTime хранятся в формате минут от начала суток (0..1439),
 * что упрощает сравнение и отображение без временных зон.
 */
@Entity(
    tableName = "schedule",
    foreignKeys = [
        ForeignKey(
            entity = Group::class,
            parentColumns = ["id"],
            childColumns = ["groupId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("groupId")]
)
data class Schedule(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupId: Long,
    val weekday: Weekday,       // 1 = понедельник .. 7 = воскресенье
    val startMinuteOfDay: Int,  // например 17:00 -> 1020
    val endMinuteOfDay: Int,    // например 18:30 -> 1110
    val active: Boolean = true
)
