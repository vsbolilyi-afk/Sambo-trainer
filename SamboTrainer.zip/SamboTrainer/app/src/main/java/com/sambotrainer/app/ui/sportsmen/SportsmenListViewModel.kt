package com.sambotrainer.app.ui.sportsmen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.SportsmanStatus
import com.sambotrainer.app.domain.AttendanceStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/** Фильтры раздела "Спортсмены" (п.21). */
enum class SportsmanFilter(val label: String) {
    ALL("Все"),
    YOUNGER("Младшая"),
    OLDER("Старшая"),
    UNPAID("Не оплачено"),
    NEEDS_ATTENTION("Требуют внимания"),
    ARCHIVE("Архив")
}

data class SportsmanListItemUi(
    val id: Long,
    val fullName: String,
    val groupName: String,
    val groupId: Long,
    val paidThisMonth: Boolean,
    val needsAttention: Boolean
)

class SportsmenListViewModel(private val database: AppDatabase) : ViewModel() {

    val searchQuery = MutableStateFlow("")
    val activeFilter = MutableStateFlow(SportsmanFilter.ALL)

    private val rawList = searchQuery
        .flatMapLatest { query ->
            val status = SportsmanStatus.ACTIVE
            if (query.isBlank()) {
                database.sportsmanDao().observeByStatus(status)
            } else {
                database.sportsmanDao().search(status, query)
            }
        }

    private val archiveList = database.sportsmanDao().observeByStatus(SportsmanStatus.ARCHIVED)

    val items: StateFlow<List<SportsmanListItemUi>> = combine(
        rawList,
        archiveList,
        activeFilter,
        database.groupDao().observeAll()
    ) { active, archived, filter, groups ->
        val groupsById = groups.associateBy { it.id }
        val source = if (filter == SportsmanFilter.ARCHIVE) archived else active

        source.map { sportsman ->
            val stats = AttendanceStats.compute(database, sportsman.id)
            SportsmanListItemUi(
                id = sportsman.id,
                fullName = sportsman.fullName,
                groupName = groupsById[sportsman.groupId]?.name ?: "Группа",
                groupId = sportsman.groupId,
                paidThisMonth = stats.paidThisMonth,
                needsAttention = stats.needsAttention
            )
        }.filter { item ->
            when (filter) {
                SportsmanFilter.ALL -> true
                SportsmanFilter.YOUNGER -> groupsById[item.groupId]?.name == "Младшая"
                SportsmanFilter.OLDER -> groupsById[item.groupId]?.name == "Старшая"
                SportsmanFilter.UNPAID -> !item.paidThisMonth
                SportsmanFilter.NEEDS_ATTENTION -> item.needsAttention
                SportsmanFilter.ARCHIVE -> true
            }
        }.sortedBy { it.fullName }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun onSearchChange(value: String) {
        searchQuery.value = value
    }

    fun onFilterChange(filter: SportsmanFilter) {
        activeFilter.value = filter
    }
}
