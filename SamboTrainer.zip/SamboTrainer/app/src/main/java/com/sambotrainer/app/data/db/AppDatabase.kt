package com.sambotrainer.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.sambotrainer.app.data.dao.*
import com.sambotrainer.app.data.entity.*

/**
 * Единая локальная база данных приложения (Room + SQLite, п.4).
 * Всё хранится во внутренней памяти телефона — без сервера, без Firebase/Supabase (п.3).
 *
 * ВАЖНО (п.54): при изменении схемы в будущем — добавлять Migration-объекты
 * в getInstance(), а не увеличивать версию с fallbackToDestructiveMigration(),
 * чтобы не терять данные тренера при обновлении приложения.
 */
@Database(
    entities = [
        Sportsman::class,
        Group::class,
        Schedule::class,
        TrainingSession::class,
        Attendance::class,
        Payment::class,
        Skill::class,
        SportsmanSkill::class,
        SkillHistory::class,
        Note::class,
        Expense::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun groupDao(): GroupDao
    abstract fun sportsmanDao(): SportsmanDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun trainingSessionDao(): TrainingSessionDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun paymentDao(): PaymentDao
    abstract fun skillDao(): SkillDao
    abstract fun sportsmanSkillDao(): SportsmanSkillDao
    abstract fun skillHistoryDao(): SkillHistoryDao
    abstract fun noteDao(): NoteDao
    abstract fun expenseDao(): ExpenseDao

    companion object {
        private const val DB_NAME = "sambo_trainer.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        /** v1 -> v2: добавлено поле sportsmen.parentNotes (заметки о родителях). Данные не теряются. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE sportsmen ADD COLUMN parentNotes TEXT")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }

        /** Путь к файлу БД — используется модулем резервного копирования (п.42-43). */
        fun databaseFileName(): String = DB_NAME

        /**
         * Закрывает текущее соединение с БД и сбрасывает синглтон — нужно перед
         * восстановлением из резервной копии (п.43), чтобы подменить файл на диске,
         * пока Room его не держит открытым. После вызова приложение нужно перезапустить.
         */
        @Synchronized
        fun closeCurrent() {
            INSTANCE?.close()
            INSTANCE = null
        }
    }
}
