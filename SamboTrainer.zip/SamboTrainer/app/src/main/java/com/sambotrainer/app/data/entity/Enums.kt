package com.sambotrainer.app.data.entity

/** Статус спортсмена: активен или переведён в архив (п.40). */
enum class SportsmanStatus {
    ACTIVE,
    ARCHIVED
}

/** Статус посещения одной тренировки (п.11). */
enum class AttendanceStatus {
    PRESENT,      // 🟢 Посетил
    ABSENT,       // 🔴 Не посетил
    NOT_MARKED    // ⚪ Не отмечено
}

/** Тип абонемента (п.14). */
enum class PaymentType {
    MONTH,       // Месяц — 4500₽, 3 занятия в неделю
    HALF_MONTH,  // Полмесяца — 3500₽
    SINGLE       // Разовое занятие — 600₽
}

/** Статус освоения навыка (п.25-28). */
enum class SkillStatus {
    IN_PROGRESS, // 🔴 В работе
    MASTERED     // 🟢 Освоено
}

/** Тип расхода (п.36-37). */
enum class ExpenseType {
    RENT,   // автоматический расход за аренду
    MANUAL  // расход, добавленный тренером вручную
}

/**
 * День недели для расписания (п.9).
 * Значения 1..7, где 1 = понедельник ... 7 = воскресенье (ISO-8601 / java.time.DayOfWeek.value).
 */
typealias Weekday = Int
