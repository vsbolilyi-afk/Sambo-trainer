package com.sambotrainer.app.data.settings

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sambotrainer.app.domain.RentSettings
import com.sambotrainer.app.domain.SubscriptionPrices
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "sambo_trainer_settings")

/**
 * Настройки, которые тренер может менять в разделе "Ещё" (п.47):
 * цены абонементов (п.14), стоимость аренды (п.36), включение автобэкапа (п.45),
 * включение уведомлений (п.46). Хранится отдельно от Room, так как это
 * простые ключ-значение настройки, а не структурированные данные.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val MONTH_PRICE = intPreferencesKey("month_price")
        val HALF_MONTH_PRICE = intPreferencesKey("half_month_price")
        val SINGLE_PRICE = intPreferencesKey("single_price")
        val RENT_PER_DAY = intPreferencesKey("rent_per_day")
        val AUTO_BACKUP = stringPreferencesKey("auto_backup") // "off" | "daily" | "weekly"
        val NOTIFICATIONS_ENABLED = stringPreferencesKey("notifications_enabled") // "on" | "off"
        val REAL_ROSTER_SEEDED = stringPreferencesKey("real_roster_seeded") // "yes" | absent
    }

    val monthPrice: Flow<Int> = context.dataStore.data.map { it[Keys.MONTH_PRICE] ?: SubscriptionPrices.MONTH_PRICE }
    val halfMonthPrice: Flow<Int> = context.dataStore.data.map { it[Keys.HALF_MONTH_PRICE] ?: SubscriptionPrices.HALF_MONTH_PRICE }
    val singlePrice: Flow<Int> = context.dataStore.data.map { it[Keys.SINGLE_PRICE] ?: SubscriptionPrices.SINGLE_PRICE }
    val rentPerDay: Flow<Int> = context.dataStore.data.map { it[Keys.RENT_PER_DAY] ?: RentSettings.RENT_PER_TRAINING_DAY }
    val autoBackup: Flow<String> = context.dataStore.data.map { it[Keys.AUTO_BACKUP] ?: "off" }
    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map { (it[Keys.NOTIFICATIONS_ENABLED] ?: "on") == "on" }

    suspend fun setMonthPrice(value: Int) = context.dataStore.edit { it[Keys.MONTH_PRICE] = value }
    suspend fun setHalfMonthPrice(value: Int) = context.dataStore.edit { it[Keys.HALF_MONTH_PRICE] = value }
    suspend fun setSinglePrice(value: Int) = context.dataStore.edit { it[Keys.SINGLE_PRICE] = value }
    suspend fun setRentPerDay(value: Int) = context.dataStore.edit { it[Keys.RENT_PER_DAY] = value }
    suspend fun setAutoBackup(value: String) = context.dataStore.edit { it[Keys.AUTO_BACKUP] = value }
    suspend fun setNotificationsEnabled(value: Boolean) = context.dataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = if (value) "on" else "off" }

    suspend fun isRealRosterSeeded(): Boolean = context.dataStore.data.map { it[Keys.REAL_ROSTER_SEEDED] == "yes" }.first()
    suspend fun setRealRosterSeeded() { context.dataStore.edit { it[Keys.REAL_ROSTER_SEEDED] = "yes" } }
}
