package com.sambotrainer.app.ui.sportsmen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.util.DateUtils

@Composable
fun ProgressSection(database: AppDatabase, sportsmanId: Long) {
    val viewModel: ProgressViewModel = viewModel(
        factory = viewModelFactory { initializer { ProgressViewModel(database, sportsmanId) } }
    )
    val inProgress by viewModel.inProgress.collectAsState()
    val mastered by viewModel.mastered.collectAsState()
    val available by viewModel.availableToAssign.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var commentTargetId by remember { mutableStateOf<Long?>(null) }
    var historyTargetId by remember { mutableStateOf<Long?>(null) }

    Column {
        TextButton(onClick = { showAddDialog = true }) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.height(18.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text("Добавить навык")
        }

        if (inProgress.isEmpty() && mastered.isEmpty()) {
            Text(
                "Навыки ещё не добавлены",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (inProgress.isNotEmpty()) {
            Text("🔴 В работе", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(4.dp))
            inProgress.forEach { skill ->
                SkillRowInProgress(
                    name = skill.name,
                    onMastered = { viewModel.markMastered(skill.sportsmanSkillId) },
                    onComment = { commentTargetId = skill.sportsmanSkillId },
                    onNameClick = { historyTargetId = skill.sportsmanSkillId }
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (mastered.isNotEmpty()) {
            Text("🟢 Освоено", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(4.dp))
            mastered.forEach { skill ->
                SkillRowMastered(
                    name = skill.name,
                    completedAt = skill.completedAt,
                    onClick = { historyTargetId = skill.sportsmanSkillId }
                )
            }
        }
    }

    if (showAddDialog) {
        AddSkillDialog(
            available = available,
            onDismiss = { showAddDialog = false },
            onPickExisting = { skillId ->
                viewModel.assignExisting(skillId)
                showAddDialog = false
            },
            onCreateNew = { name ->
                viewModel.createAndAssign(name)
                showAddDialog = false
            }
        )
    }

    commentTargetId?.let { id ->
        CommentDialog(
            onDismiss = { commentTargetId = null },
            onSave = { text ->
                viewModel.addComment(id, text)
                commentTargetId = null
            }
        )
    }

    historyTargetId?.let { id ->
        SkillHistoryDialog(
            historyFlow = viewModel.historyFor(id),
            onDismiss = { historyTargetId = null }
        )
    }
}

@Composable
private fun SkillRowInProgress(name: String, onMastered: () -> Unit, onComment: () -> Unit, onNameClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            name,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.clickable(onClick = onNameClick)
        )
        Row {
            TextButton(onClick = onComment) { Text("Комментарий") }
            TextButton(onClick = onMastered) { Text("ОСВОЕНО") }
        }
    }
}

@Composable
private fun SkillRowMastered(name: String, completedAt: Long?, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable(onClick = onClick),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(name, style = MaterialTheme.typography.bodyLarge)
        val dateText = completedAt?.let { DateUtils.formatDayMonth(DateUtils.epochToLocalDate(it)) } ?: ""
        Text(dateText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AddSkillDialog(
    available: List<com.sambotrainer.app.data.entity.Skill>,
    onDismiss: () -> Unit,
    onPickExisting: (Long) -> Unit,
    onCreateNew: (String) -> Unit
) {
    var newSkillName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить навык") },
        text = {
            Column {
                if (available.isNotEmpty()) {
                    Text("Из каталога:", style = MaterialTheme.typography.labelLarge)
                    LazyColumn(modifier = Modifier.height(180.dp)) {
                        items(available, key = { it.id }) { skill ->
                            Text(
                                skill.name,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onPickExisting(skill.id) }
                                    .padding(vertical = 10.dp)
                            )
                            HorizontalDivider()
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }
                Text("Или новый навык:", style = MaterialTheme.typography.labelLarge)
                OutlinedTextField(
                    value = newSkillName,
                    onValueChange = { newSkillName = it },
                    placeholder = { Text("Например: Бросок через бедро") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreateNew(newSkillName) }, enabled = newSkillName.isNotBlank()) {
                Text("Создать и добавить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

@Composable
private fun CommentDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Комментарий к навыку") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Например: начал выполнять самостоятельно") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(text) }, enabled = text.isNotBlank()) { Text("Сохранить") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

@Composable
private fun SkillHistoryDialog(
    historyFlow: kotlinx.coroutines.flow.Flow<List<com.sambotrainer.app.data.entity.SkillHistory>>,
    onDismiss: () -> Unit
) {
    val history by historyFlow.collectAsState(initial = emptyList())
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("История навыка") },
        text = {
            if (history.isEmpty()) {
                Text("Пока нет записей", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(modifier = Modifier.height(220.dp)) {
                    items(history) { entry ->
                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                            Text(
                                DateUtils.formatDayMonth(DateUtils.epochToLocalDate(entry.date)),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(entry.comment ?: "", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Закрыть") }
        }
    )
}
