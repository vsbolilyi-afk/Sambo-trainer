package com.sambotrainer.app.data.dao

import androidx.room.*
import com.sambotrainer.app.data.entity.TrainingSession
import kotlinx.coroutines.flow.Flow

@Dao
interface TrainingSessionDao {

    /** Тренировки на конкретный день (для главного экрана "Сегодня", п.6). */
    @Query("SELECT * FROM training_sessions WHERE date = :dayStart ORDER BY startMinuteOfDay ASC")
    fun observeForDay(dayStart: Long): Flow<List<TrainingSession>>

    /** Тренировки в диапазоне дат (для календаря месяца, п.32). */
    @Query("SELECT * FROM training_sessions WHERE date >= :from AND date <= :to ORDER BY date ASC, startMinuteOfDay ASC")
    fun observeForRange(from: Long, to: Long): Flow<List<TrainingSession>>

    @Query("SELECT * FROM training_sessions WHERE date >= :from AND date <= :to")
    suspend fun getForRange(from: Long, to: Long): List<TrainingSession>

    @Query("SELECT * FROM training_sessions WHERE id = :id")
    suspend fun getById(id: Long): TrainingSession?

    @Query("SELECT * FROM training_sessions WHERE groupId = :groupId AND date = :dayStart LIMIT 1")
    suspend fun findExisting(groupId: Long, dayStart: Long): TrainingSession?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(session: TrainingSession): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(sessions: List<TrainingSession>)

    @Delete
    suspend fun delete(session: TrainingSession)

    /** Для подсчёта тренировочных дней в месяце -> автоматический расход на аренду (п.36). */
    @Query("SELECT COUNT(*) FROM training_sessions WHERE date >= :from AND date <= :to")
    suspend fun countInRange(from: Long, to: Long): Int
}
