package com.sambotrainer.app.ui.sportsmen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Skill
import com.sambotrainer.app.data.entity.SkillHistory
import com.sambotrainer.app.data.entity.SkillStatus
import com.sambotrainer.app.data.entity.SportsmanSkill
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SportsmanSkillUi(
    val sportsmanSkillId: Long,
    val skillId: Long,
    val name: String,
    val status: SkillStatus,
    val completedAt: Long?
)

class ProgressViewModel(
    private val database: AppDatabase,
    private val sportsmanId: Long
) : ViewModel() {

    private val allSkills = database.skillDao().observeAll()
    private val assignments = database.sportsmanSkillDao().observeForSportsman(sportsmanId)

    private fun mapUi(list: List<SportsmanSkill>, skills: List<Skill>, status: SkillStatus): List<SportsmanSkillUi> {
        val byId = skills.associateBy { it.id }
        return list.filter { it.status == status }
            .mapNotNull { ss -> byId[ss.skillId]?.let { skill ->
                SportsmanSkillUi(ss.id, skill.id, skill.name, ss.status, ss.completedAt)
            } }
            .sortedBy { it.name }
    }

    val inProgress: StateFlow<List<SportsmanSkillUi>> = combine(assignments, allSkills) { list, skills ->
        mapUi(list, skills, SkillStatus.IN_PROGRESS)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mastered: StateFlow<List<SportsmanSkillUi>> = combine(assignments, allSkills) { list, skills ->
        mapUi(list, skills, SkillStatus.MASTERED)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Навыки из общего каталога (п.26), ещё не назначенные этому спортсмену — для диалога добавления. */
    val availableToAssign: StateFlow<List<Skill>> = combine(allSkills, assignments) { skills, assigned ->
        val assignedIds = assigned.map { it.skillId }.toSet()
        skills.filter { it.active && it.id !in assignedIds }.sortedBy { it.name }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun assignExisting(skillId: Long) {
        viewModelScope.launch { assignInternal(skillId) }
    }

    /** Тренер может создать новый навык прямо здесь — он попадает в общий каталог (п.26-27). */
    fun createAndAssign(name: String) {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return
        viewModelScope.launch {
            val skillId = database.skillDao().insert(Skill(name = trimmed))
            assignInternal(skillId)
        }
    }

    private suspend fun assignInternal(skillId: Long) {
        val id = database.sportsmanSkillDao().insert(SportsmanSkill(sportsmanId = sportsmanId, skillId = skillId))
        database.skillHistoryDao().insert(
            SkillHistory(sportsmanSkillId = id, date = System.currentTimeMillis(), status = SkillStatus.IN_PROGRESS, comment = "Навык добавлен")
        )
    }

    /** Одно нажатие "ОСВОЕНО" — без диалогов подтверждения (п.28). */
    fun markMastered(sportsmanSkillId: Long) {
        viewModelScope.launch {
            val current = database.sportsmanSkillDao().getById(sportsmanSkillId) ?: return@launch
            val now = System.currentTimeMillis()
            database.sportsmanSkillDao().update(current.copy(status = SkillStatus.MASTERED, completedAt = now))
            database.skillHistoryDao().insert(
                SkillHistory(sportsmanSkillId = sportsmanSkillId, date = now, status = SkillStatus.MASTERED, comment = "Освоено")
            )
        }
    }

    /** Комментарий к навыку без смены статуса (например "Начал выполнять самостоятельно", п.29). */
    fun addComment(sportsmanSkillId: Long, comment: String) {
        if (comment.isBlank()) return
        viewModelScope.launch {
            val current = database.sportsmanSkillDao().getById(sportsmanSkillId) ?: return@launch
            database.skillHistoryDao().insert(
                SkillHistory(sportsmanSkillId = sportsmanSkillId, date = System.currentTimeMillis(), status = current.status, comment = comment.trim())
            )
        }
    }

    fun historyFor(sportsmanSkillId: Long): Flow<List<SkillHistory>> =
        database.skillHistoryDao().observeForSportsmanSkill(sportsmanSkillId)
}
