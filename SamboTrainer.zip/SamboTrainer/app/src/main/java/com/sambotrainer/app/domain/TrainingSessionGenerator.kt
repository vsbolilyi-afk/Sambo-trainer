package com.sambotrainer.app.domain

import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.TrainingSession
import com.sambotrainer.app.util.DateUtils
import java.time.LocalDate

/**
 * Автоматическое создание тренировок по расписанию (п.10).
 *
 * Тренер никогда не создаёт тренировки вручную: если в расписании на среду
 * стоит "Младшая 17:00–18:30", приложение само создаёт TrainingSession на
 * каждую подходящую дату — идемпотентно (повторный вызов не плодит дубликаты).
 */
object TrainingSessionGenerator {

    /** Гарантирует, что для заданной даты созданы все тренировки по активному расписанию. */
    suspend fun ensureSessionsForDate(database: AppDatabase, date: LocalDate) {
        val weekday = date.dayOfWeek.value // 1=Пн .. 7=Вс, совпадает с нашим Schedule.weekday
        val schedules = database.scheduleDao().getActiveForWeekday(weekday)
        if (schedules.isEmpty()) return

        val dayStart = DateUtils.toEpochDayStart(date)
        val sessionDao = database.trainingSessionDao()

        for (schedule in schedules) {
            val existing = sessionDao.findExisting(schedule.groupId, dayStart)
            if (existing == null) {
                sessionDao.insert(
                    TrainingSession(
                        groupId = schedule.groupId,
                        date = dayStart,
                        startMinuteOfDay = schedule.startMinuteOfDay,
                        endMinuteOfDay = schedule.endMinuteOfDay,
                        sourceScheduleId = schedule.id
                    )
                )
            }
        }
    }

    /** То же самое для диапазона дат — понадобится экрану "Календарь" (Фаза 5, п.32-33). */
    suspend fun ensureSessionsForRange(database: AppDatabase, from: LocalDate, to: LocalDate) {
        var d = from
        while (!d.isAfter(to)) {
            ensureSessionsForDate(database, d)
            d = d.plusDays(1)
        }
    }
}
