package com.sambotrainer.app.backup

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Constraints
import java.util.concurrent.TimeUnit

/**
 * Планирование автоматического резервного копирования (п.45).
 * Сейчас поддерживается режим "раз в неделю" — по значению настройки
 * SettingsRepository.autoBackup ("off" | "weekly").
 */
object WorkScheduler {
    private const val AUTO_BACKUP_WORK_NAME = "auto_backup_weekly"

    /** Без требования интернета/зарядки — резервная копия работает полностью офлайн (п.3). */
    private val noConstraints = Constraints.Builder().setRequiredNetworkType(NetworkType.NOT_REQUIRED).build()

    fun scheduleWeeklyBackup(context: Context) {
        val request = PeriodicWorkRequestBuilder<AutoBackupWorker>(7, TimeUnit.DAYS)
            .setConstraints(noConstraints)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            AUTO_BACKUP_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP, // не сбрасывать уже запланированное расписание при каждом запуске приложения
            request
        )
    }

    fun cancelAutoBackup(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(AUTO_BACKUP_WORK_NAME)
    }

    /** Приводит фактическое расписание в соответствие с сохранённой настройкой (вызывается при каждом запуске приложения). */
    fun syncWithSetting(context: Context, autoBackupValue: String) {
        when (autoBackupValue) {
            "weekly" -> scheduleWeeklyBackup(context)
            else -> cancelAutoBackup(context)
        }
    }
}
