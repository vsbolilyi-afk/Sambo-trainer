package com.sambotrainer.app.ui.sportsmen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.domain.SubscriptionPrices
import com.sambotrainer.app.util.ContactIntents
import com.sambotrainer.app.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SportsmanCardScreen(
    database: AppDatabase,
    settingsRepository: com.sambotrainer.app.data.settings.SettingsRepository,
    sportsmanId: Long,
    onBack: () -> Unit,
    onEdit: (Long) -> Unit = {}
) {
    val viewModel: SportsmanCardViewModel = viewModel(
        factory = viewModelFactory { initializer { SportsmanCardViewModel(database, sportsmanId) } }
    )
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val sportsman = state.sportsman

    var showPaymentDialog by remember { mutableStateOf(false) }
    var showArchiveConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(sportsman?.fullName ?: "") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    IconButton(onClick = { onEdit(sportsmanId) }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Изменить")
                    }
                }
            )
        }
    ) { padding ->
        if (sportsman == null) return@Scaffold

        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(state.groupName, style = MaterialTheme.typography.bodyLarge)
            Text(
                "Дата рождения: ${DateUtils.formatDayMonth(DateUtils.epochToLocalDate(sportsman.birthDate))}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))
            SectionCard(title = "Контакты") {
                ContactInfoRow("Родитель", sportsman.parentName)
                ContactInfoRow("Телефон родителя", sportsman.parentPhone)
                ContactInfoRow("Телефон спортсмена", sportsman.sportsmanPhone)
                ContactInfoRow("Max", sportsman.maxContact)
                ContactInfoRow("Telegram", sportsman.telegramContact)
                ContactInfoRow("Социальная сеть", sportsman.socialContact)
                sportsman.startDate?.let {
                    ContactInfoRow("Начало занятий", DateUtils.formatDayMonth(DateUtils.epochToLocalDate(it)))
                }
                if (sportsman.parentName == null && sportsman.parentPhone == null && sportsman.sportsmanPhone == null &&
                    sportsman.maxContact == null && sportsman.telegramContact == null && sportsman.socialContact == null
                ) {
                    Text(
                        "Контакты не указаны — нажмите ✎ в шапке, чтобы добавить",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (sportsman.parentPhone != null || sportsman.telegramContact != null || sportsman.maxContact != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        sportsman.parentPhone?.let {
                            QuickActionButton("Позвонить", Icons.Filled.Call) { ContactIntents.call(context, it) }
                        }
                        sportsman.parentPhone?.let {
                            QuickActionButton("SMS", Icons.Filled.Sms) { ContactIntents.sms(context, it) }
                        }
                        sportsman.telegramContact?.let {
                            QuickActionButton("Telegram", Icons.Filled.Send) { ContactIntents.telegram(context, it) }
                        }
                        sportsman.maxContact?.let {
                            QuickActionButton("Max", Icons.Filled.Send) { ContactIntents.max(context, it) }
                        }
                    }
                }
            }

            if (!sportsman.parentNotes.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                SectionCard(title = "О родителях") {
                    Text(sportsman.parentNotes, style = MaterialTheme.typography.bodyLarge)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            SectionCard(title = "Оплата — ${DateUtils.monthNominative(java.time.LocalDate.now().monthValue)}") {
                val paid = state.stats?.paidThisMonth == true
                val monthTotal = state.payments
                    .filter { it.month == DateUtils.monthKey(java.time.LocalDate.now()) }
                    .sumOf { it.amount }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(if (paid) "🟢 Оплачено" else "🔴 Не оплачено", style = MaterialTheme.typography.titleMedium)
                        if (paid) {
                            Text("$monthTotal ₽", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Button(onClick = { showPaymentDialog = true }) { Text(if (paid) "Добавить оплату" else "Отметить оплату") }
                }

                if (state.payments.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text("История оплат", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(6.dp))
                    state.payments.forEach { payment ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    DateUtils.formatDayMonth(DateUtils.epochToLocalDate(payment.paymentDate)),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    SubscriptionPrices.labelFor(payment.type) + (payment.comment?.let { " · $it" } ?: ""),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text("${payment.amount} ₽", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            SectionCard(title = "Посещаемость") {
                val stats = state.stats
                if (stats != null) {
                    Text("Посещений: ${stats.totalPresent}")
                    Text("Пропусков: ${stats.totalAbsent}")
                    Text("Процент посещаемости: ${stats.attendancePercent}%")
                    if (stats.unpaidPresentCountThisMonth > 0 && !stats.paidThisMonth) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "⚠️ Занятий без оплаты в этом месяце: ${stats.unpaidPresentCountThisMonth}",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            SectionCard(title = "Спортивный прогресс") {
                ProgressSection(database = database, sportsmanId = sportsman.id)
            }

            Spacer(modifier = Modifier.height(16.dp))
            SectionCard(title = "Заметки") {
                NotesSection(database = database, sportsmanId = sportsman.id)
            }

            Spacer(modifier = Modifier.height(16.dp))
            SectionCard(title = "⚠️ Важная информация") {
                var text by remember(sportsman.id) { mutableStateOf(sportsman.importantInformation ?: "") }
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Например: ограничить нагрузку на колено") },
                    minLines = 2
                )
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = { viewModel.updateImportantInformation(text) }) {
                    Text("Сохранить")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            if (sportsman.status == com.sambotrainer.app.data.entity.SportsmanStatus.ARCHIVED) {
                Button(
                    onClick = { viewModel.restore() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Восстановить из архива")
                }
            } else {
                OutlinedButton(
                    onClick = { showArchiveConfirm = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Перевести в архив")
                }
            }
            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    if (showPaymentDialog) {
        PaymentTypeDialog(
            settingsRepository = settingsRepository,
            onDismiss = { showPaymentDialog = false },
            onConfirm = { type, amount, comment ->
                viewModel.markPayment(type, amount, comment)
                showPaymentDialog = false
            }
        )
    }

    if (showArchiveConfirm) {
        AlertDialog(
            onDismissRequest = { showArchiveConfirm = false },
            title = { Text("Перевести в архив?") },
            text = { Text("Данные спортсмена не удаляются и доступны для восстановления из архива.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.archive()
                    showArchiveConfirm = false
                    onBack()
                }) { Text("Перевести в архив") }
            },
            dismissButton = {
                TextButton(onClick = { showArchiveConfirm = false }) { Text("Отмена") }
            }
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun ContactInfoRow(label: String, value: String?) {
    if (value.isNullOrBlank()) return
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun QuickActionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick) {
        Icon(icon, contentDescription = label, modifier = Modifier.height(18.dp))
        Spacer(modifier = Modifier.height(6.dp))
        Text(label)
    }
}
