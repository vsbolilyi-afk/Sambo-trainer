package com.sambotrainer.app.ui.sportsmen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Note
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NotesViewModel(
    private val database: AppDatabase,
    private val sportsmanId: Long
) : ViewModel() {

    val notes: StateFlow<List<Note>> = database.noteDao().observeForSportsman(sportsmanId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            database.noteDao().insert(Note(sportsmanId = sportsmanId, date = System.currentTimeMillis(), text = text.trim()))
        }
    }

    fun update(note: Note, newText: String) {
        if (newText.isBlank()) return
        viewModelScope.launch {
            database.noteDao().update(note.copy(text = newText.trim()))
        }
    }

    fun delete(note: Note) {
        viewModelScope.launch {
            database.noteDao().delete(note)
        }
    }
}
