package com.sambotrainer.app.ui.sportsmen

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.util.DateUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditSportsmanScreen(
    database: AppDatabase,
    sportsmanId: Long,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val viewModel: EditSportsmanViewModel = viewModel(
        factory = viewModelFactory { initializer { EditSportsmanViewModel(database, sportsmanId) } }
    )
    val sportsman by viewModel.sportsman.collectAsState()
    val groups by viewModel.groups.collectAsState()
    val scope = rememberCoroutineScope()

    var loaded by remember { mutableStateOf(false) }

    var fullName by remember { mutableStateOf("") }
    var selectedGroupId by remember { mutableStateOf<Long?>(null) }
    var groupMenuExpanded by remember { mutableStateOf(false) }
    var birthDateMillis by remember { mutableStateOf<Long?>(null) }
    var showBirthDatePicker by remember { mutableStateOf(false) }
    var startDateMillis by remember { mutableStateOf<Long?>(null) }
    var showStartDatePicker by remember { mutableStateOf(false) }

    var parentName by remember { mutableStateOf("") }
    var parentPhone by remember { mutableStateOf("") }
    var sportsmanPhone by remember { mutableStateOf("") }
    var maxContact by remember { mutableStateOf("") }
    var telegramContact by remember { mutableStateOf("") }
    var socialContact by remember { mutableStateOf("") }
    var importantInformation by remember { mutableStateOf("") }
    var parentNotes by remember { mutableStateOf("") }

    var showDuplicateWarning by remember { mutableStateOf(false) }

    // Заполняем форму, как только данные спортсмена загрузились из базы (один раз).
    LaunchedEffect(sportsman) {
        val s = sportsman ?: return@LaunchedEffect
        if (loaded) return@LaunchedEffect
        fullName = s.fullName
        selectedGroupId = s.groupId
        birthDateMillis = s.birthDate
        startDateMillis = s.startDate
        parentName = s.parentName ?: ""
        parentPhone = s.parentPhone ?: ""
        sportsmanPhone = s.sportsmanPhone ?: ""
        maxContact = s.maxContact ?: ""
        telegramContact = s.telegramContact ?: ""
        socialContact = s.socialContact ?: ""
        importantInformation = s.importantInformation ?: ""
        parentNotes = s.parentNotes ?: ""
        loaded = true
    }

    fun performSave() {
        val groupId = selectedGroupId ?: return
        val birth = birthDateMillis ?: return
        viewModel.save(
            fullName = fullName,
            birthDateMillis = birth,
            groupId = groupId,
            parentName = parentName,
            parentPhone = parentPhone,
            sportsmanPhone = sportsmanPhone,
            maxContact = maxContact,
            telegramContact = telegramContact,
            socialContact = socialContact,
            startDateMillis = startDateMillis,
            importantInformation = importantInformation,
            parentNotes = parentNotes,
            onDone = onSaved
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Изменить спортсмена") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        }
    ) { padding ->
        if (!loaded) {
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("ФИО") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = birthDateMillis?.let { DateUtils.formatDayMonth(DateUtils.epochToLocalDate(it)) } ?: "",
                onValueChange = {},
                readOnly = true,
                label = { Text("Дата рождения") },
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    TextButton(onClick = { showBirthDatePicker = true }) { Text("Изменить") }
                }
            )
            Spacer(modifier = Modifier.height(12.dp))

            ExposedDropdownMenuBox(
                expanded = groupMenuExpanded,
                onExpandedChange = { groupMenuExpanded = it }
            ) {
                OutlinedTextField(
                    value = groups.firstOrNull { it.id == selectedGroupId }?.name ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Группа") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = groupMenuExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                DropdownMenu(
                    expanded = groupMenuExpanded,
                    onDismissRequest = { groupMenuExpanded = false }
                ) {
                    groups.forEach { group ->
                        DropdownMenuItem(
                            text = { Text(group.name) },
                            onClick = {
                                selectedGroupId = group.id
                                groupMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = startDateMillis?.let { DateUtils.formatDayMonth(DateUtils.epochToLocalDate(it)) } ?: "",
                onValueChange = {},
                readOnly = true,
                label = { Text("Дата начала занятий") },
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = {
                    TextButton(onClick = { showStartDatePicker = true }) { Text("Изменить") }
                }
            )

            Spacer(modifier = Modifier.height(20.dp))
            Text("Контакты", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(parentName, { parentName = it }, label = { Text("Имя родителя") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(parentPhone, { parentPhone = it }, label = { Text("Телефон родителя") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(sportsmanPhone, { sportsmanPhone = it }, label = { Text("Телефон спортсмена") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(maxContact, { maxContact = it }, label = { Text("Max") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(telegramContact, { telegramContact = it }, label = { Text("Telegram") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(socialContact, { socialContact = it }, label = { Text("Социальная сеть") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                importantInformation, { importantInformation = it },
                label = { Text("Важная информация") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                parentNotes, { parentNotes = it },
                label = { Text("О родителях (работа, доп. контакты и т.п.)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = {
                    val canSave = fullName.isNotBlank() && selectedGroupId != null && birthDateMillis != null
                    if (!canSave) return@Button
                    scope.launch {
                        if (viewModel.isDuplicateName(fullName)) {
                            showDuplicateWarning = true
                        } else {
                            performSave()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Сохранить изменения")
            }
        }
    }

    if (showBirthDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = birthDateMillis)
        DatePickerDialog(
            onDismissRequest = { showBirthDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { birthDateMillis = it }
                    showBirthDatePicker = false
                }) { Text("Ок") }
            },
            dismissButton = { TextButton(onClick = { showBirthDatePicker = false }) { Text("Отмена") } }
        ) { DatePicker(state = state) }
    }

    if (showStartDatePicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = startDateMillis)
        DatePickerDialog(
            onDismissRequest = { showStartDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { startDateMillis = it }
                    showStartDatePicker = false
                }) { Text("Ок") }
            },
            dismissButton = { TextButton(onClick = { showStartDatePicker = false }) { Text("Отмена") } }
        ) { DatePicker(state = state) }
    }

    if (showDuplicateWarning) {
        AlertDialog(
            onDismissRequest = { showDuplicateWarning = false },
            title = { Text("Спортсмен с таким ФИО уже есть") },
            text = { Text("Сохранить изменения всё равно?") },
            confirmButton = {
                TextButton(onClick = {
                    showDuplicateWarning = false
                    performSave()
                }) { Text("Всё равно сохранить") }
            },
            dismissButton = { TextButton(onClick = { showDuplicateWarning = false }) { Text("Отмена") } }
        )
    }
}
