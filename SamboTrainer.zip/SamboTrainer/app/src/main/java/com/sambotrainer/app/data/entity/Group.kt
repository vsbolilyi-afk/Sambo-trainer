package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Группа спортсменов (п.8). По умолчанию создаются "Младшая" и "Старшая",
 * но список редактируемый и расширяемый.
 */
@Entity(tableName = "groups")
data class Group(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val active: Boolean = true
)
