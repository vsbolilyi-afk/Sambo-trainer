package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Спортсмен (п.19, 22, 23, 56).
 * birthDate / startDate / createdAt хранятся как epoch millis (UTC).
 */
@Entity(
    tableName = "sportsmen",
    foreignKeys = [
        ForeignKey(
            entity = Group::class,
            parentColumns = ["id"],
            childColumns = ["groupId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("groupId"), Index("fullName")]
)
data class Sportsman(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fullName: String,
    val birthDate: Long,
    val groupId: Long,

    // Дополнительные поля (п.22)
    val parentName: String? = null,
    val parentPhone: String? = null,
    val sportsmanPhone: String? = null,
    val maxContact: String? = null,
    val telegramContact: String? = null,
    val socialContact: String? = null,
    val startDate: Long? = null,
    val importantInformation: String? = null,
    /** Свободные заметки о родителях: работа, доп. контакты, обстоятельства — отдельно от "важной информации" о тренировках. */
    val parentNotes: String? = null,
    val address: String? = null,
    val schoolOrKindergarten: String? = null,
    val desiredResult: String? = null,
    val additionalSections: String? = null,

    val status: SportsmanStatus = SportsmanStatus.ACTIVE,
    val createdAt: Long = System.currentTimeMillis()
)
