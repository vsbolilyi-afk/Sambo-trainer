package com.sambotrainer.app.data.dao

import androidx.room.*
import com.sambotrainer.app.data.entity.Payment
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {

    @Query("SELECT * FROM payments WHERE sportsmanId = :sportsmanId ORDER BY paymentDate DESC")
    fun observeForSportsman(sportsmanId: Long): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE sportsmanId = :sportsmanId AND month = :month")
    suspend fun getForSportsmanMonth(sportsmanId: Long, month: String): List<Payment>

    @Query("SELECT EXISTS(SELECT 1 FROM payments WHERE sportsmanId = :sportsmanId AND month = :month)")
    fun observeHasPaymentForMonth(sportsmanId: Long, month: String): Flow<Boolean>

    @Query("SELECT * FROM payments WHERE month = :month ORDER BY paymentDate DESC")
    fun observeForMonth(month: String): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE month = :month")
    suspend fun getForMonth(month: String): List<Payment>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE month = :month")
    fun observeIncomeForMonth(month: String): Flow<Int>

    @Insert
    suspend fun insert(payment: Payment): Long

    @Update
    suspend fun update(payment: Payment)

    @Delete
    suspend fun delete(payment: Payment)

    @Query("SELECT * FROM payments")
    suspend fun getAllForExport(): List<Payment>
}
