package com.sambotrainer.app

import android.app.Application
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Group
import com.sambotrainer.app.data.entity.Schedule
import com.sambotrainer.app.data.settings.SettingsRepository
import com.sambotrainer.app.demo.DemoDataSeeder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SamboTrainerApp : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }

    override fun onCreate() {
        super.onCreate()
        // Строго последовательно: сначала группы/расписание, ТОЛЬКО ПОТОМ демо-данные,
        // иначе DemoDataSeeder может не найти группы ещё не вставленными (гонка корутин).
        applicationScope.launch {
            seedDefaultsIfNeeded()
            DemoDataSeeder.seedIfEmpty(database)
        }
    }

    /**
     * При первом запуске создаём две группы по умолчанию (п.8) и их расписание (п.9).
     * suspend-функция (не launch внутри launch), чтобы вызывающий код мог дождаться
     * завершения перед тем, как сидировать демо-данные поверх.
     */
    private suspend fun seedDefaultsIfNeeded() {
        val groupDao = database.groupDao()
        val scheduleDao = database.scheduleDao()

        val groups = groupDao.observeAll().first()
        if (groups.isNotEmpty()) return

        val youngerId = groupDao.insert(Group(name = "Младшая", active = true))
        val olderId = groupDao.insert(Group(name = "Старшая", active = true))

        // Младшая: Пн, Ср, Пт 17:00–18:30
        listOf(1, 3, 5).forEach { weekday ->
            scheduleDao.insert(
                Schedule(
                    groupId = youngerId,
                    weekday = weekday,
                    startMinuteOfDay = 17 * 60,
                    endMinuteOfDay = 18 * 60 + 30,
                    active = true
                )
            )
        }

        // Старшая: Вт, Чт 17:00–18:30
        listOf(2, 4).forEach { weekday ->
            scheduleDao.insert(
                Schedule(
                    groupId = olderId,
                    weekday = weekday,
                    startMinuteOfDay = 17 * 60,
                    endMinuteOfDay = 18 * 60 + 30,
                    active = true
                )
            )
        }

        // Суббота 13:00–14:30 — по ТЗ редактируемое занятие, по умолчанию для старшей группы (п.9)
        scheduleDao.insert(
            Schedule(
                groupId = olderId,
                weekday = 6,
                startMinuteOfDay = 13 * 60,
                endMinuteOfDay = 14 * 60 + 30,
                active = true
            )
        )
    }
}
