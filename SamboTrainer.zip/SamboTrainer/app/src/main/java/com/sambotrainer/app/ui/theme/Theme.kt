package com.sambotrainer.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

/**
 * Базовая светлая тема. Полноценный премиальный дизайн в духе Liquid Glass
 * (полупрозрачные карточки, матовое стекло, кастомная типографика — п.49)
 * будет добавлен в отдельной фазе визуальной полировки, чтобы не смешивать
 * функциональную и визуальную работу.
 */
private val LightColors = lightColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFF1C1C1E),
    onPrimary = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFFF2F2F7)
)

@Composable
fun SamboTrainerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        content = content
    )
}
