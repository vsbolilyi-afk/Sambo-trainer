package com.sambotrainer.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * Премиальная светлая тема приложения (п.49): тёплый фон, почти чёрный текст,
 * один сдержанный акцент, крупные скругления, уверенная типографика.
 *
 * Поскольку почти весь экранный код ссылается на MaterialTheme.colorScheme /
 * .typography / .shapes, а не на захардкоженные значения, изменения здесь
 * применяются сразу ко всему приложению — без правки каждого экрана.
 */
private val AppColorScheme = lightColorScheme(
    primary = AppColors.Ink,
    onPrimary = Color.White,
    secondary = AppColors.Accent,
    onSecondary = Color.White,
    tertiary = AppColors.Accent,

    background = AppColors.Background,
    onBackground = AppColors.Ink,

    surface = AppColors.Surface,
    onSurface = AppColors.Ink,
    surfaceVariant = AppColors.SurfaceVariant,
    onSurfaceVariant = AppColors.InkSecondary,

    outline = AppColors.Outline,
    outlineVariant = AppColors.Outline,

    error = AppColors.Danger,
    onError = Color.White,
    errorContainer = AppColors.DangerBg,
    onErrorContainer = AppColors.Danger
)

@Composable
fun SamboTrainerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
