package com.sambotrainer.app.data.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Отметка посещения одного спортсмена на одной тренировке (п.11, 13, 16).
 * Одна запись на пару (sportsmanId, trainingSessionId).
 */
@Entity(
    tableName = "attendance",
    foreignKeys = [
        ForeignKey(
            entity = Sportsman::class,
            parentColumns = ["id"],
            childColumns = ["sportsmanId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = TrainingSession::class,
            parentColumns = ["id"],
            childColumns = ["trainingSessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("sportsmanId"),
        Index("trainingSessionId"),
        Index(value = ["sportsmanId", "trainingSessionId"], unique = true)
    ]
)
data class Attendance(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sportsmanId: Long,
    val trainingSessionId: Long,
    val status: AttendanceStatus = AttendanceStatus.NOT_MARKED,
    val createdAt: Long = System.currentTimeMillis()
)
