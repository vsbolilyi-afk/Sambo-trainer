package com.sambotrainer.app.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.sambotrainer.app.data.entity.SkillHistory
import kotlinx.coroutines.flow.Flow

@Dao
interface SkillHistoryDao {

    @Query("SELECT * FROM skill_history WHERE sportsmanSkillId = :sportsmanSkillId ORDER BY date ASC")
    fun observeForSportsmanSkill(sportsmanSkillId: Long): Flow<List<SkillHistory>>

    @Insert
    suspend fun insert(history: SkillHistory): Long
}
