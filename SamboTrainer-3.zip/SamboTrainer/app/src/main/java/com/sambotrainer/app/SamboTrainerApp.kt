package com.sambotrainer.app

import android.app.Application
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.data.entity.Group
import com.sambotrainer.app.data.entity.Schedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class SamboTrainerApp : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }

    override fun onCreate() {
        super.onCreate()
        seedDefaultsIfNeeded()
    }

    /**
     * При первом запуске создаём две группы по умолчанию (п.8) и их расписание (п.9).
     * Полные демо-данные (спортсмены, посещения, оплаты — п.58) добавляются отдельным
     * этапом поверх этого базового сидирования.
     */
    private fun seedDefaultsIfNeeded() {
        applicationScope.launch {
            val groupDao = database.groupDao()
            val scheduleDao = database.scheduleDao()

            // Разовая проверка при первом старте: если группы уже есть — ничего не делаем.
            val groups = groupDao.observeAll().first()
            if (groups.isNotEmpty()) return@launch

            val youngerId = groupDao.insert(Group(name = "Младшая", active = true))
            val olderId = groupDao.insert(Group(name = "Старшая", active = true))

            // Младшая: Пн, Ср, Пт 17:00–18:30
            listOf(1, 3, 5).forEach { weekday ->
                scheduleDao.insert(
                    Schedule(
                        groupId = youngerId,
                        weekday = weekday,
                        startMinuteOfDay = 17 * 60,
                        endMinuteOfDay = 18 * 60 + 30,
                        active = true
                    )
                )
            }

            // Старшая: Вт, Чт 17:00–18:30
            listOf(2, 4).forEach { weekday ->
                scheduleDao.insert(
                    Schedule(
                        groupId = olderId,
                        weekday = weekday,
                        startMinuteOfDay = 17 * 60,
                        endMinuteOfDay = 18 * 60 + 30,
                        active = true
                    )
                )
            }

            // Суббота 13:00–14:30 — по ТЗ редактируемое занятие, по умолчанию для старшей группы (п.9)
            scheduleDao.insert(
                Schedule(
                    groupId = olderId,
                    weekday = 6,
                    startMinuteOfDay = 13 * 60,
                    endMinuteOfDay = 14 * 60 + 30,
                    active = true
                )
            )
        }
    }
}
