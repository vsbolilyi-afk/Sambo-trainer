package com.sambotrainer.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.navArgument
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.sambotrainer.app.data.db.AppDatabase
import com.sambotrainer.app.ui.attendance.AttendanceScreen
import com.sambotrainer.app.ui.common.PlaceholderScreen
import com.sambotrainer.app.ui.navigation.DetailRoutes
import com.sambotrainer.app.ui.navigation.Screen
import com.sambotrainer.app.ui.sportsmen.AddSportsmanScreen
import com.sambotrainer.app.ui.sportsmen.SportsmanCardScreen
import com.sambotrainer.app.ui.sportsmen.SportsmenListScreen
import com.sambotrainer.app.ui.today.TodayScreen

/**
 * Корень UI приложения: нижняя навигация из 5 разделов (п.7) + NavHost.
 * Фаза 3 добавляет: список спортсменов, карточку спортсмена и отметку
 * посещаемости тренировки — детальные экраны, открывающиеся поверх
 * нижней навигации (без своего пункта в NavigationBar).
 */
@Composable
fun SamboTrainerRoot(database: AppDatabase) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination?.route

            NavigationBar {
                Screen.bottomBarItems.forEach { screen ->
                    NavigationBarItem(
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Today.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Today.route) {
                TodayScreen(
                    database = database,
                    onSessionClick = { sessionId ->
                        navController.navigate(DetailRoutes.attendance(sessionId))
                    }
                )
            }

            composable(Screen.Sportsmen.route) {
                SportsmenListScreen(
                    database = database,
                    onSportsmanClick = { id ->
                        navController.navigate(DetailRoutes.sportsmanCard(id))
                    },
                    onAddClick = {
                        navController.navigate(DetailRoutes.ADD_SPORTSMAN)
                    }
                )
            }

            composable(Screen.Calendar.route) {
                PlaceholderScreen(Screen.Calendar.label)
            }
            composable(Screen.Payments.route) {
                PlaceholderScreen(Screen.Payments.label)
            }
            composable(Screen.More.route) {
                PlaceholderScreen(Screen.More.label)
            }

            composable(
                route = DetailRoutes.SPORTSMAN_CARD,
                arguments = listOf(navArgument("sportsmanId") { type = NavType.LongType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getLong("sportsmanId") ?: return@composable
                SportsmanCardScreen(
                    database = database,
                    sportsmanId = id,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = DetailRoutes.ATTENDANCE,
                arguments = listOf(navArgument("sessionId") { type = NavType.LongType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getLong("sessionId") ?: return@composable
                AttendanceScreen(
                    database = database,
                    sessionId = id,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(DetailRoutes.ADD_SPORTSMAN) {
                AddSportsmanScreen(
                    database = database,
                    onBack = { navController.popBackStack() },
                    onSaved = { id ->
                        navController.popBackStack()
                        navController.navigate(DetailRoutes.sportsmanCard(id))
                    }
                )
            }
        }
    }
}
