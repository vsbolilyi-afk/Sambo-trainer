package com.sambotrainer.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.sambotrainer.app.ui.SamboTrainerRoot
import com.sambotrainer.app.ui.theme.SamboTrainerTheme

/**
 * Точка входа приложения.
 *
 * Фаза 2: нижняя навигация (п.7) и экран "Сегодня" (п.6) с автоматическим
 * созданием тренировок по расписанию (п.10). Остальные разделы — заглушки,
 * которые будут заменены в следующих фазах.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = (application as SamboTrainerApp).database

        setContent {
            SamboTrainerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SamboTrainerRoot(database)
                }
            }
        }
    }
}
